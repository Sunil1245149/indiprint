export interface Service {
  id: string;
  service_name: string;
  service_label: string;
  price: number;
  enabled: boolean;
}

export interface Shop {
  id: string;
  mobile: string;
  shop_name: string;
  upi_id: string;
  require_prepayment: boolean;
  services: Service[];
}

export interface Upload {
  id: string;
  file_name: string;
  file_type: string;
  file_size: number;
  file_url: string;
  password?: string;
}

export interface Job {
  id: string;
  shop_id: string;
  customer_name: string;
  customer_mobile: string;
  service_type: string;
  total_amount: number;
  status: 'PENDING' | 'PROCESSING' | 'PRINTED';
  payment_status: 'PENDING' | 'PAID';
  created_at: string;
  uploads: Upload[];
}
