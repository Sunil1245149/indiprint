import { useState, useEffect } from 'react';
import HomePortal from './components/HomePortal';
import CustomerPortal from './components/CustomerPortal';
import MerchantPortal from './components/MerchantPortal';

type Page = 'home' | 'customer' | 'merchant';

export default function App() {
  const [activePage, setActivePage] = useState<Page>('home');

  // Detect URL on initial load and handle deep links
  useEffect(() => {
    const handleUrlChange = () => {
      const path = window.location.pathname.toLowerCase();
      if (path.includes('merchant')) {
        setActivePage('merchant');
      } else if (path.includes('customer')) {
        setActivePage('customer');
      } else {
        setActivePage('home');
      }
    };

    // Run on mount
    handleUrlChange();

    // Listen to browser back/forward buttons
    window.addEventListener('popstate', handleUrlChange);
    return () => {
      window.removeEventListener('popstate', handleUrlChange);
    };
  }, []);

  // Safe navigation function that updates URL bar without full page reload
  const navigate = (page: Page) => {
    setActivePage(page);
    const targetPath = page === 'home' ? '/' : `/${page}`;
    window.history.pushState(null, '', targetPath);
  };

  return (
    <div className="bg-slate-950 min-h-screen text-slate-100 selection:bg-indigo-500/30 selection:text-indigo-200 relative overflow-x-hidden">
      {/* Background Mesh Gradients */}
      <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] bg-indigo-600/15 blur-[120px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] bg-purple-600/15 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="relative z-10">
        {activePage === 'home' && (
          <HomePortal onNavigate={navigate} />
        )}
        {activePage === 'customer' && (
          <CustomerPortal onNavigate={navigate} />
        )}
        {activePage === 'merchant' && (
          <MerchantPortal onNavigate={navigate} />
        )}
      </div>
    </div>
  );
}
