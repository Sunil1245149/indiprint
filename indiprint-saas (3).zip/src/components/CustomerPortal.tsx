import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { 
  Smartphone, Search, AlertCircle, Building, CheckCircle, 
  ChevronLeft, User, FileText, Download, Camera, 
  ShoppingBag, CreditCard, X, ArrowLeft
} from 'lucide-react';
import { Shop } from '../types';

interface CustomerPortalProps {
  onNavigate: (page: 'home' | 'customer' | 'merchant') => void;
}

interface CartItem {
  id: string;
  service_type: string;
  label: string;
  price: number;
  files: Array<{
    name: string;
    base64Data: string;
    type: string;
    size: number;
    password?: string;
  }>;
  qty: number;
  specSummary: string;
}

export default function CustomerPortal({ onNavigate }: CustomerPortalProps) {
  const [shopSearchInput, setShopSearchInput] = useState('');
  const [shop, setShop] = useState<Shop | null>(null);
  const [isLoadingShop, setIsLoadingShop] = useState(false);
  const [shopError, setShopError] = useState('');

  const [activeWorkflow, setActiveWorkflow] = useState<'home' | 'id_card' | 'pdf' | 'photo' | 'passport'>('home');

  // Customer state
  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');

  // Cart
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCheckoutSubmitted, setIsCheckoutSubmitted] = useState(false);
  const [submittedJobTicket, setSubmittedJobTicket] = useState<any>(null);

  // --- Form states ---
  // 1. ID Card
  const [idCardFront, setIdCardFront] = useState<string | null>(null);
  const [idCardFrontName, setIdCardFrontName] = useState('');
  const [idCardBack, setIdCardBack] = useState<string | null>(null);
  const [idCardBackName, setIdCardBackName] = useState('');
  const [idCardType, setIdCardType] = useState('duplex');
  const [idCardQty, setIdCardQty] = useState(1);

  // 2. PDF
  const [pdfFileList, setPdfFileList] = useState<Array<{ name: string; size: number; base64: string }>>([]);
  const [pdfPassword, setPdfPassword] = useState('');
  const [pdfColorPref, setPdfColorPref] = useState('b_w_print_a4');
  const [pdfDuplex, setPdfDuplex] = useState('single_side');
  const [pdfCopies, setPdfCopies] = useState(1);

  // 3. Photo Print
  const [photoFileList, setPhotoFileList] = useState<Array<{ name: string; size: number; base64: string }>>([]);
  const [photoSize, setPhotoSize] = useState('photo_print_4x6');
  const [photoPaperPref, setPhotoPaperPref] = useState('glossy');
  const [photoQty, setPhotoQty] = useState(1);

  // 4. Passport Photo
  const [passportGridUrl, setPassportGridUrl] = useState<string | null>(null);
  const [passportCount, setPassportCount] = useState(8);
  const [passportBgType, setPassportBgType] = useState('white');
  const [passportName, setPassportName] = useState('');

  // Checkout UPI modal
  const [showPayModal, setShowPayModal] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState('');

  // Convert file to Base64 helper
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  // Check URL parameter for pre-loaded shop
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const shopParam = params.get('shop');
    if (shopParam) {
      loadShopDetails(shopParam);
    }
  }, []);

  const totalFinalPrice = cartItems.reduce((acc, item) => acc + (item.price * item.qty), 0);

  // Generate UPI QR Code image source URL
  useEffect(() => {
    if (showPayModal && shop) {
      const upiLink = `upi://pay?pa=${shop.upi_id}&pn=${encodeURIComponent(shop.shop_name)}&am=${totalFinalPrice}&cu=INR&tn=IndiPrintOrder`;
      QRCode.toDataURL(upiLink, { margin: 1, width: 250 })
        .then(url => {
          setQrCodeDataUrl(url);
        })
        .catch(err => {
          console.error('Failed to generate dynamic UPI QR code:', err);
        });
    }
  }, [showPayModal, shop, totalFinalPrice]);

  const loadShopDetails = async (mobileKey: string) => {
    setIsLoadingShop(true);
    setShopError('');
    try {
      const res = await fetch(`/api/shop/${mobileKey}`);
      if (!res.ok) {
        setShopError('Store could not be located. Double check the mobile number.');
        setShop(null);
      } else {
        const data = await res.json();
        setShop(data);
        setShopSearchInput(mobileKey);
      }
    } catch (err) {
      setShopError('Connection issue. Please retry.');
    } finally {
      setIsLoadingShop(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (shopSearchInput.trim()) {
      loadShopDetails(shopSearchInput.trim());
    }
  };

  const getRate = (serviceName: string) => {
    if (!shop || !shop.services) return 5;
    const svc = shop.services.find(s => s.service_name === serviceName);
    return svc && svc.enabled ? svc.price : 5;
  };

  const addToCart = (item: CartItem) => {
    setCartItems(prev => [...prev, item]);
    setActiveWorkflow('home');
  };

  const removeFromCart = (id: string) => {
    setCartItems(prev => prev.filter(i => i.id !== id));
  };

  const handleIdCardSubmit = () => {
    if (!idCardFront) {
      alert('Please upload front side image first.');
      return;
    }
    const serviceSlug = idCardType === 'duplex' ? 'id_card_duplex' : 'id_card_single';
    const itemPrice = getRate(serviceSlug);
    const files = [
      { name: idCardFrontName || 'ID_Front.jpg', base64Data: idCardFront, type: 'image/jpeg', size: 120000 }
    ];
    if (idCardType === 'duplex' && idCardBack) {
      files.push({ name: idCardBackName || 'ID_Back.jpg', base64Data: idCardBack, type: 'image/jpeg', size: 120000 });
    }

    addToCart({
      id: 'item_' + Date.now(),
      service_type: 'id_card',
      label: idCardType === 'duplex' ? 'ID Card Duplex Booklet' : 'ID Single Sided Card',
      price: itemPrice,
      qty: idCardQty,
      specSummary: `Copies: ${idCardQty} | Mode: ${idCardType.toUpperCase()}`,
      files
    });

    // Reset Form
    setIdCardFront(null);
    setIdCardFrontName('');
    setIdCardBack(null);
    setIdCardBackName('');
    setIdCardQty(1);
  };

  const handlePdfSubmit = () => {
    if (pdfFileList.length === 0) {
      alert('Please select at least one PDF file.');
      return;
    }
    const ratePerSheet = getRate(pdfColorPref);

    addToCart({
      id: 'item_' + Date.now(),
      service_type: 'pdf',
      label: `PDF Documents (${pdfFileList.length} Files)`,
      price: ratePerSheet * pdfFileList.length,
      qty: pdfCopies,
      specSummary: `Copies: ${pdfCopies} | Color: ${pdfColorPref === 'color_print_a4' ? 'Color' : 'B&W'} | Layout: ${pdfDuplex === 'double_side' ? 'Double Sided (Duplex)' : 'Single-Side'}`,
      files: pdfFileList.map(f => ({
        name: f.name,
        base64Data: f.base64,
        type: 'application/pdf',
        size: f.size,
        password: pdfPassword || undefined
      }))
    });

    // Reset Form
    setPdfFileList([]);
    setPdfPassword('');
    setPdfCopies(1);
  };

  const handlePhotoSubmit = () => {
    if (photoFileList.length === 0) {
      alert('Please upload your photo to print.');
      return;
    }
    const sizeRate = getRate(photoSize);

    addToCart({
      id: 'item_' + Date.now(),
      service_type: 'photo',
      label: `High-Gloss Photo Print (${photoFileList.length} Pics)`,
      price: sizeRate * photoFileList.length,
      qty: photoQty,
      specSummary: `Copies: ${photoQty} | Size: ${photoSize === 'photo_print_a4' ? 'A4 poster sheet' : '4x6" card'} | Quality: ${photoPaperPref.toUpperCase()}`,
      files: photoFileList.map(f => ({
        name: f.name,
        base64Data: f.base64,
        type: 'image/jpeg',
        size: f.size
      }))
    });

    // Reset Form
    setPhotoFileList([]);
    setPhotoQty(1);
  };

  const handlePassportSubmit = () => {
    if (!passportGridUrl) {
      alert('Please upload your raw photo/selfie first.');
      return;
    }
    const itemPrice = getRate('passport_photo_set');

    addToCart({
      id: 'item_' + Date.now(),
      service_type: 'passport',
      label: `Passport Photo Set (${passportCount} Pics)`,
      price: itemPrice,
      qty: 1,
      specSummary: `Copies: ${passportCount} | Preferred Background: ${passportBgType.toUpperCase()}`,
      files: [
        { name: passportName || `User_Portrait.jpg`, base64Data: passportGridUrl, type: 'image/jpeg', size: 250000 }
      ]
    });

    // Reset Form
    setPassportGridUrl(null);
    setPassportName('');
  };

  const handleQueueCheckout = async () => {
    if (!customerName.trim()) {
      alert('Please specify your name for the print ticket.');
      return;
    }

    try {
      const payload = {
        shop_id: shop?.id,
        customer_name: customerName,
        customer_mobile: customerMobile,
        service_type: cartItems[0]?.service_type || 'multiple',
        total_amount: totalFinalPrice,
        payment_status: shop?.require_prepayment ? 'PAID' : 'PENDING',
        files: cartItems.flatMap(item => item.files)
      };

      const res = await fetch('/api/jobs/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (res.ok) {
        setSubmittedJobTicket(data.job);
        setIsCheckoutSubmitted(true);
        setCartItems([]);
        setShowPayModal(false);
      } else {
        alert('Queue failure: ' + (data.error || 'Server rejected order'));
      }
    } catch (err) {
      alert('Network issue committing order. Please check internet connection.');
    }
  };

  return (
    <div className="min-h-screen bg-transparent text-slate-100 flex flex-col justify-between selection:bg-indigo-500/30 selection:text-indigo-200">
      
      {/* Header */}
      <header className="bg-white/5 backdrop-blur-xl border-b border-white/10 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <button 
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 hover:opacity-90 transition text-left cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white font-extrabold shadow-lg shadow-indigo-500/25">
              <Smartphone className="w-5.5 h-5.5 text-white" />
            </div>
            <div>
              <span className="font-black text-lg tracking-tight bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">IndiPrint</span>
              <span className="text-[10px] text-indigo-400 block font-bold tracking-widest uppercase -mt-1 font-mono">Customer Portal</span>
            </div>
          </button>

          <button
            onClick={() => onNavigate('home')}
            className="px-3.5 py-1.5 text-xs font-bold text-slate-300 hover:text-white flex items-center gap-1.5 cursor-pointer bg-white/5 border border-white/10 backdrop-blur-md rounded-xl"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-4xl mx-auto p-4 md:p-6 space-y-6 flex-grow w-full">
        
        {/* Step 1: Search shop lock if not loaded */}
        {!shop ? (
          <div className="max-w-md mx-auto my-12 bg-white/5 border border-white/10 backdrop-blur-xl p-8 rounded-3xl shadow-xl">
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white font-extrabold mx-auto mb-2 shadow-lg shadow-indigo-500/20">
                <Smartphone className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-black text-white">Xerox Mobile Desk</h2>
              <p className="text-xs text-slate-300 mt-1">Scan store QR or input merchant's 10-digit number to begin</p>
            </div>

            {shopError && (
              <div className="p-3.5 bg-rose-500/10 border border-rose-550/20 text-rose-200 text-xs rounded-xl flex items-center gap-2 mb-4">
                <AlertCircle className="w-4.5 h-4.5 text-rose-400 shrink-0" />
                <span>{shopError}</span>
              </div>
            )}

            <form onSubmit={handleSearchSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] text-slate-300 font-bold uppercase mb-1.5">Enter Store Mobile (मोबाइल नंबर)</label>
                <div className="relative">
                  <Search className="w-4.5 h-4.5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="tel" 
                    placeholder="e.g. 9876543210"
                    value={shopSearchInput}
                    onChange={(e) => setShopSearchInput(e.target.value)}
                    className="w-full bg-black/20 border border-white/10 pl-11 pr-4 py-3 rounded-2xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoadingShop}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold rounded-2xl transition uppercase tracking-wider cursor-pointer shadow-lg shadow-indigo-600/20"
              >
                {isLoadingShop ? 'Connecting...' : 'Access Printing Desk'}
              </button>
            </form>
          </div>
        ) : (
          
          // Core guest desk workspace
          <div className="space-y-6">
            
            {/* Loaded Shop metadata banner */}
            <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg animate-fade-in">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white font-extrabold shadow-lg shadow-indigo-500/20">
                  <Building className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="font-extrabold text-slate-100 text-base">{shop.shop_name}</h2>
                  <p className="text-xs text-slate-300 mt-0.5 font-mono">Counter: {shop.mobile} • Live Xerox Portal</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => { setShop(null); setCartItems([]); setIsCheckoutSubmitted(false); }}
                className="py-1.5 px-3 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-[10px] font-bold rounded-xl backdrop-blur-md transition cursor-pointer"
              >
                Change Store
              </button>
            </div>

            {/* Ticket Submission Success View */}
            {isCheckoutSubmitted && submittedJobTicket ? (
              <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-8 rounded-3xl text-center space-y-6 max-w-lg mx-auto shadow-lg animate-fade-in">
                <div className="w-12 h-12 bg-white/10 text-indigo-400 border border-white/10 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="font-black text-slate-100 text-lg">Order Sent to Xerox Counter!</h3>
                  <p className="text-xs text-slate-300 mt-1">Please note your digital token number and show it at the shop counter</p>
                </div>

                <div className="p-5 bg-black/20 border border-white/10 rounded-2xl font-mono text-xs text-left space-y-2">
                  <div className="flex justify-between border-b border-white/5 pb-1.5 font-bold">
                    <span className="text-slate-400">PRINT TICKET:</span>
                    <span className="text-indigo-400 font-extrabold">#{submittedJobTicket.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Customer:</span>
                    <span className="text-slate-300">{submittedJobTicket.customer_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Service:</span>
                    <span className="text-slate-300 uppercase">{submittedJobTicket.service_type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Est Price:</span>
                    <span className="text-indigo-400">₹{submittedJobTicket.total_amount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Status:</span>
                    <span className="text-indigo-400 font-bold">IN QUEUE (Automatic Spool)</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => { setIsCheckoutSubmitted(false); setSubmittedJobTicket(null); }}
                  className="py-3 px-6 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-2xl uppercase tracking-wider transition w-full cursor-pointer shadow-lg shadow-indigo-600/20"
                >
                  Send Another Document
                </button>
              </div>
            ) : (
              
              // Dashboard selection or active workflows
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Left Column - Form selectors and active view */}
                <div className="lg:col-span-8">
                  
                  {activeWorkflow === 'home' && (
                    <div className="space-y-4">
                      <span className="block text-[11px] font-black text-slate-500 uppercase tracking-widest">Select Printing Utility (सर्विस चुनें):</span>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        
                        {/* 1. ID Card Booklet */}
                        <button
                          type="button"
                          onClick={() => setActiveWorkflow('id_card')}
                          className="bg-white/5 border border-white/10 hover:border-indigo-500/50 hover:bg-white/10 p-5 rounded-2xl text-left backdrop-blur-xl transition relative overflow-hidden group flex gap-4 cursor-pointer shadow-lg"
                        >
                          <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-indigo-400 border border-white/10 shrink-0">
                            <User className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-100 text-xs">ID Card Booklet (पहचान पत्र)</h4>
                            <p className="text-[10px] text-slate-300 leading-normal mt-1">Perfect side-by-side automatic spacing for Aadhar, Voter ID, or DL copies.</p>
                            <span className="inline-block mt-2 text-[9px] font-mono font-bold text-indigo-400">Rate: ₹{getRate('id_card_duplex')} booklet</span>
                          </div>
                        </button>

                        {/* 2. PDF Documents */}
                        <button
                          type="button"
                          onClick={() => setActiveWorkflow('pdf')}
                          className="bg-white/5 border border-white/10 hover:border-indigo-500/50 hover:bg-white/10 p-5 rounded-2xl text-left backdrop-blur-xl transition relative overflow-hidden group flex gap-4 cursor-pointer shadow-lg"
                        >
                          <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-indigo-400 border border-white/10 shrink-0">
                            <FileText className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-100 text-xs">PDF Printing (डॉक्युमेंट प्रिंट)</h4>
                            <p className="text-[10px] text-slate-300 leading-normal mt-1">Upload pass-locked salary slips, receipts, or forms easily and securely.</p>
                            <span className="inline-block mt-2 text-[9px] font-mono font-bold text-indigo-400">Rate: ₹{getRate('b_w_print_a4')} per side (A4)</span>
                          </div>
                        </button>

                        {/* 3. Photo Printing */}
                        <button
                          type="button"
                          onClick={() => setActiveWorkflow('photo')}
                          className="bg-white/5 border border-white/10 hover:border-indigo-500/50 hover:bg-white/10 p-5 rounded-2xl text-left backdrop-blur-xl transition relative overflow-hidden group flex gap-4 cursor-pointer shadow-lg"
                        >
                          <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-indigo-400 border border-white/10 shrink-0">
                            <Download className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-100 text-xs">Photo Print (फोटो प्रिंटिंग)</h4>
                            <p className="text-[10px] text-slate-300 leading-normal mt-1">High-quality visual rendering on glossy or matte 4x6" card sheets.</p>
                            <span className="inline-block mt-2 text-[9px] font-mono font-bold text-indigo-400">Rate: ₹{getRate('photo_print_4x6')} print card</span>
                          </div>
                        </button>

                        {/* 4. Passport Photo Set */}
                        <button
                          type="button"
                          onClick={() => setActiveWorkflow('passport')}
                          className="bg-white/5 border border-white/10 hover:border-indigo-500/50 hover:bg-white/10 p-5 rounded-2xl text-left backdrop-blur-xl transition relative overflow-hidden group flex gap-4 cursor-pointer shadow-lg"
                        >
                          <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-indigo-400 border border-white/10 shrink-0">
                            <Camera className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-100 text-xs">Passport Size Set (पासपोर्ट साइज)</h4>
                            <p className="text-[10px] text-slate-300 leading-normal mt-1">Upload selfie or photo. Choose background recolor and print 4-16 set pics.</p>
                            <span className="inline-block mt-2 text-[9px] font-mono font-bold text-indigo-400">Rate: ₹{getRate('passport_photo_set')} set sheet</span>
                          </div>
                        </button>

                      </div>
                    </div>
                  )}

                  {/* ID Card Form flow */}
                  {activeWorkflow === 'id_card' && (
                    <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl space-y-5 shadow-lg animate-fade-in">
                      <div className="flex items-center gap-2.5 border-b border-white/10 pb-3">
                        <button type="button" onClick={() => setActiveWorkflow('home')} className="hover:bg-white/10 p-1.5 bg-white/5 border border-white/10 rounded-lg text-slate-300 transition cursor-pointer"><ChevronLeft className="w-4 h-4" /></button>
                        <div>
                          <h3 className="font-extrabold text-slate-100 text-xs">ID Card Booklet Xerox Setup</h3>
                          <p className="text-[10px] text-slate-400">Avoid Xerox errors. Upload clear front & back snapshots for side-by-side automatic spooling</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <span className="block text-[10px] text-slate-300 font-bold uppercase mb-1.5">1. Front Side (सामने का भाग)</span>
                          {idCardFront ? (
                            <div className="relative border border-white/10 rounded-xl overflow-hidden bg-black/20">
                              <img src={idCardFront} className="h-32 w-full object-cover" />
                              <button type="button" onClick={() => { setIdCardFront(null); setIdCardFrontName(''); }} className="absolute top-2 right-2 p-1.5 bg-rose-950/80 hover:bg-rose-900 text-rose-250 rounded-lg text-xs font-bold transition cursor-pointer"><X className="w-3.5 h-3.5" /></button>
                            </div>
                          ) : (
                            <div className="relative border-2 border-dashed border-white/10 rounded-xl p-6 bg-black/10 text-center hover:border-indigo-500/45 transition">
                              <input 
                                type="file" 
                                accept="image/*"
                                onChange={async (e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const base64 = await fileToBase64(file);
                                    setIdCardFront(base64);
                                    setIdCardFrontName(file.name);
                                  }
                                }}
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                              />
                              <Camera className="w-6 h-6 text-slate-400 mx-auto mb-1.5" />
                              <span className="text-[10px] text-slate-300 block font-bold">Upload front side image</span>
                            </div>
                          )}
                        </div>

                        <div>
                          <span className="block text-[10px] text-slate-300 font-bold uppercase mb-1.5">2. Back Side (पीछे का भाग)</span>
                          {idCardBack ? (
                            <div className="relative border border-white/10 rounded-xl overflow-hidden bg-black/20">
                              <img src={idCardBack} className="h-32 w-full object-cover" />
                              <button type="button" onClick={() => { setIdCardBack(null); setIdCardBackName(''); }} className="absolute top-2 right-2 p-1.5 bg-rose-950/80 hover:bg-rose-900 text-rose-250 rounded-lg text-xs font-bold transition cursor-pointer"><X className="w-3.5 h-3.5" /></button>
                            </div>
                          ) : (
                            <div className="relative border-2 border-dashed border-white/10 rounded-xl p-6 bg-black/10 text-center hover:border-indigo-500/45 transition">
                              <input 
                                type="file" 
                                accept="image/*"
                                onChange={async (e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const base64 = await fileToBase64(file);
                                    setIdCardBack(base64);
                                    setIdCardBackName(file.name);
                                  }
                                }}
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                              />
                              <Camera className="w-6 h-6 text-slate-400 mx-auto mb-1.5" />
                              <span className="text-[10px] text-slate-300 block font-bold">Upload back side image</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-xs pt-2">
                        <div>
                          <span className="block text-slate-300 font-bold uppercase text-[9px] mb-1.5">Xerox Layout type</span>
                          <select 
                            value={idCardType}
                            onChange={(e) => setIdCardType(e.target.value)}
                            className="w-full bg-black/20 border border-white/10 p-2 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                          >
                            <option value="duplex">Booklet Front + Back side-by-side (₹{getRate('id_card_duplex')})</option>
                            <option value="single">Single Side Front page only (₹{getRate('id_card_single')})</option>
                          </select>
                        </div>
                        <div>
                          <span className="block text-slate-300 font-bold uppercase text-[9px] mb-1.5">Copies / Quantity</span>
                          <input 
                            type="number"
                            min="1"
                            value={idCardQty}
                            onChange={(e) => setIdCardQty(Math.max(1, parseInt(e.target.value) || 1))}
                            className="w-full bg-black/20 border border-white/10 p-2 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500 font-mono"
                          />
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handleIdCardSubmit}
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition uppercase tracking-wider mt-4 cursor-pointer shadow-lg shadow-indigo-600/20"
                      >
                        Lock Booklet & Add to Cart
                      </button>
                    </div>
                  )}

                  {/* PDF Document Upload Form */}
                  {activeWorkflow === 'pdf' && (
                    <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl space-y-5 shadow-lg animate-fade-in">
                      <div className="flex items-center gap-2.5 border-b border-white/10 pb-3">
                        <button type="button" onClick={() => setActiveWorkflow('home')} className="hover:bg-white/10 p-1.5 bg-white/5 border border-white/10 rounded-lg text-slate-300 transition cursor-pointer"><ChevronLeft className="w-4 h-4" /></button>
                        <div>
                          <h3 className="font-extrabold text-slate-100 text-xs">PDF Documents Xerox Portal</h3>
                          <p className="text-[10px] text-slate-400">Provide locked doc passwords securely so store printers auto-decouple them</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <span className="block text-[10px] text-slate-300 font-bold uppercase mb-1.5">Upload PDF files</span>
                          <div className="relative border-2 border-dashed border-white/10 hover:border-indigo-500/40 rounded-2xl bg-black/10 p-6 transition text-center">
                            <input 
                              type="file" 
                              accept="application/pdf"
                              multiple
                              onChange={async (e) => {
                                const files = Array.from(e.target.files || []) as File[];
                                for (const file of files) {
                                  const base64 = await fileToBase64(file);
                                  setPdfFileList(prev => [...prev, { name: file.name, size: file.size, base64 }]);
                                }
                              }}
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                            />
                            <FileText className="w-8 h-8 text-indigo-400 mx-auto mb-1.5" />
                            <span className="text-xs font-bold text-slate-300 block">Click to browse or drop A4 PDFs</span>
                            <span className="text-[9px] text-slate-400 block mt-1">Supports payslips, receipts, statements, tickets</span>
                          </div>
                        </div>

                        {/* List uploaded PDFs */}
                        {pdfFileList.length > 0 && (
                          <div className="space-y-2">
                            <span className="block text-[9px] text-slate-400 font-black uppercase tracking-wider">Queue uploads:</span>
                            {pdfFileList.map((file, idx) => (
                              <div key={idx} className="p-2.5 bg-black/20 border border-white/5 rounded-xl flex items-center justify-between text-xs animate-fade-in">
                                <span className="font-bold text-slate-300 truncate max-w-xs">{file.name}</span>
                                <button 
                                  type="button" 
                                  onClick={() => setPdfFileList(prev => prev.filter((_, i) => i !== idx))} 
                                  className="p-1 hover:bg-white/5 text-slate-400 hover:text-rose-400 rounded-lg transition cursor-pointer"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <span className="block text-slate-300 font-bold uppercase text-[9px] mb-1.5">PDF Password / Code (वैकल्पिक पासवर्ड)</span>
                            <input 
                              type="password"
                              placeholder="If file is locked (e.g. salary slip)"
                              value={pdfPassword}
                              onChange={(e) => setPdfPassword(e.target.value)}
                              className="w-full bg-black/20 border border-white/10 p-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500 font-mono"
                            />
                          </div>
                          <div>
                            <span className="block text-slate-300 font-bold uppercase text-[9px] mb-1.5">Color Format Preference</span>
                            <select 
                              value={pdfColorPref}
                              onChange={(e) => setPdfColorPref(e.target.value)}
                              className="w-full bg-black/20 border border-white/10 p-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                            >
                              <option value="b_w_print_a4">B&W Printing Eco (₹{getRate('b_w_print_a4')}/side)</option>
                              <option value="color_print_a4">High Gloss Color (₹{getRate('color_print_a4')}/side)</option>
                            </select>
                          </div>
                        </div>

                      </div>

                      <button
                        type="button"
                        onClick={handlePdfSubmit}
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition uppercase tracking-wider mt-4 cursor-pointer shadow-lg shadow-indigo-600/20"
                      >
                        Lock PDFs & Add to Cart
                      </button>
                    </div>
                  )}
                  {/* Photo Printing Form */}
                  {activeWorkflow === 'photo' && (
                    <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl space-y-5 shadow-lg animate-fade-in">
                      <div className="flex items-center gap-2.5 border-b border-white/10 pb-3">
                        <button type="button" onClick={() => setActiveWorkflow('home')} className="hover:bg-white/10 p-1.5 bg-white/5 border border-white/10 rounded-lg text-slate-300 transition cursor-pointer"><ChevronLeft className="w-4 h-4" /></button>
                        <div>
                          <h3 className="font-extrabold text-slate-100 text-xs">Gloss Photo Printing</h3>
                          <p className="text-[10px] text-slate-400">Perfect photo rendering for framing, albums, or wallets</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <span className="block text-[10px] text-slate-300 font-bold uppercase mb-1.5">Upload high-res images</span>
                          <div className="relative border-2 border-dashed border-white/10 hover:border-indigo-500/40 rounded-2xl bg-black/10 p-6 transition text-center">
                            <input 
                              type="file" 
                              accept="image/*"
                              multiple
                              onChange={async (e) => {
                                const files = Array.from(e.target.files || []) as File[];
                                for (const file of files) {
                                  const base64 = await fileToBase64(file);
                                  setPhotoFileList(prev => [...prev, { name: file.name, size: file.size, base64 }]);
                                }
                              }}
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                            />
                            <Download className="w-8 h-8 text-indigo-400 mx-auto mb-1.5" />
                            <span className="text-xs font-bold text-slate-300 block">Click to upload photos to print</span>
                            <span className="text-[9px] text-slate-400 block mt-1">Supports album layouts, profiles, snapshots</span>
                          </div>
                        </div>

                        {photoFileList.length > 0 && (
                          <div className="space-y-2">
                            <span className="block text-[9px] text-slate-400 font-black uppercase tracking-wider">Queue uploads:</span>
                            {photoFileList.map((file, idx) => (
                              <div key={idx} className="p-2.5 bg-black/20 border border-white/5 rounded-xl flex items-center justify-between text-xs animate-fade-in">
                                <span className="font-bold text-slate-300 truncate max-w-xs">{file.name}</span>
                                <button 
                                  type="button" 
                                  onClick={() => setPhotoFileList(prev => prev.filter((_, i) => i !== idx))} 
                                  className="p-1 hover:bg-white/5 text-slate-400 hover:text-rose-400 rounded-lg transition cursor-pointer"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                          <div>
                            <span className="block text-slate-300 font-bold uppercase text-[9px] mb-1.5">Print Card Size</span>
                            <select 
                              value={photoSize}
                              onChange={(e) => setPhotoSize(e.target.value)}
                              className="w-full bg-black/20 border border-white/10 p-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                            >
                              <option value="photo_print_4x6">Standard Card Size 4" x 6" (₹{getRate('photo_print_4x6')}/print)</option>
                              <option value="photo_print_a4">Full sheet A4 Poster (₹{getRate('photo_print_a4') || 40}/print)</option>
                            </select>
                          </div>
                          <div>
                            <span className="block text-slate-300 font-bold uppercase text-[9px] mb-1.5">Paper Quality Texture</span>
                            <select 
                              value={photoPaperPref}
                              onChange={(e) => setPhotoPaperPref(e.target.value)}
                              className="w-full bg-black/20 border border-white/10 p-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                            >
                              <option value="glossy">High-Gloss Premium paper</option>
                              <option value="matte">Matte Fine Art finish</option>
                            </select>
                          </div>
                        </div>

                      </div>

                      <button
                        type="button"
                        onClick={handlePhotoSubmit}
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition uppercase tracking-wider mt-4 cursor-pointer shadow-lg shadow-indigo-600/20"
                      >
                        Lock Photos & Add to Cart
                      </button>
                    </div>
                  )}

                  {/* Passport Size Photo Form */}
                  {activeWorkflow === 'passport' && (
                    <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl space-y-5 shadow-lg animate-fade-in">
                      <div className="flex items-center gap-2.5 border-b border-white/10 pb-3">
                        <button type="button" onClick={() => { setActiveWorkflow('home'); setPassportGridUrl(null); }} className="hover:bg-white/10 p-1.5 bg-white/5 border border-white/10 rounded-lg text-slate-300 transition cursor-pointer"><ChevronLeft className="w-4 h-4" /></button>
                        <div>
                          <h3 className="font-extrabold text-slate-100 text-xs">Passport Size Photo Orders</h3>
                          <p className="text-[10px] text-slate-400">We will align, crop, recolor background and print perfectly</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <span className="block text-[10px] text-slate-300 font-bold uppercase mb-1.5">1. Target Quantity (कितनी कॉपी चाहिए)</span>
                          <div className="grid grid-cols-4 gap-2">
                            {[4, 8, 12, 16].map((cnt) => (
                              <button
                                key={cnt}
                                type="button"
                                onClick={() => setPassportCount(cnt)}
                                className={`py-3 px-2 rounded-2xl font-black text-xs border transition flex flex-col items-center justify-center gap-1 cursor-pointer ${
                                  passportCount === cnt 
                                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-600/20' 
                                    : 'bg-black/20 border-white/10 text-slate-300 hover:text-white'
                                }`}
                              >
                                <span>{cnt} Pics</span>
                                <span className="text-[8px] font-mono opacity-75">Package</span>
                              </button>
                            ))}
                          </div>
                        </div>

                        <div>
                          <span className="block text-[10px] text-slate-300 font-bold uppercase mb-1.5">2. Choose Background Tone</span>
                          <div className="grid grid-cols-5 gap-1.5">
                            {[
                              { id: 'white', name: 'White', hex: '#ffffff' },
                              { id: 'sky_blue', name: 'Sky Blue', hex: '#a5f3fc' },
                              { id: 'royal_blue', name: 'Royal Blue', hex: '#2563eb' },
                              { id: 'red', name: 'Red', hex: '#ef4444' },
                              { id: 'original', name: 'Original', hex: 'transparent' }
                            ].map((opt) => (
                              <button
                                key={opt.id}
                                type="button"
                                onClick={() => setPassportBgType(opt.id)}
                                className={`p-2 rounded-xl border text-center text-[9px] font-bold transition flex flex-col items-center gap-1 cursor-pointer ${
                                  passportBgType === opt.id 
                                    ? 'bg-indigo-600/10 border-indigo-500 text-indigo-400' 
                                    : 'bg-black/20 border-white/10 text-slate-300 hover:text-white'
                                }`}
                              >
                                <div className="w-3.5 h-3.5 rounded-full border border-white/10" style={{ backgroundColor: opt.hex === 'transparent' ? '#1e293b' : opt.hex }} />
                                <span className="truncate max-w-full text-[8px]">{opt.name}</span>
                              </button>
                            ))}
                          </div>
                        </div>

                        <div>
                          <span className="block text-[10px] text-slate-300 font-bold uppercase mb-1.5">3. Upload selfie/portrait</span>
                          {passportGridUrl ? (
                            <div className="p-3 bg-black/20 border border-white/10 rounded-2xl flex items-center justify-between gap-3 text-xs">
                              <div className="flex items-center gap-2.5">
                                <img src={passportGridUrl} className="w-10 h-10 object-cover rounded-xl" />
                                <div className="text-left">
                                  <span className="font-bold text-slate-300 block">{passportName || 'User_Portrait.jpg'}</span>
                                  <span className="text-[9px] text-indigo-400 block font-mono">Snapshot locked</span>
                                </div>
                              </div>
                              <button type="button" onClick={() => { setPassportGridUrl(null); setPassportName(''); }} className="p-1 hover:bg-white/10 text-slate-300 hover:text-rose-400 rounded-lg transition cursor-pointer"><X className="w-4 h-4" /></button>
                            </div>
                          ) : (
                            <div className="relative border-2 border-dashed border-white/10 rounded-2xl bg-black/10 p-6 transition text-center hover:border-indigo-500/40">
                              <input 
                                type="file" 
                                accept="image/*"
                                onChange={async (e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const base64 = await fileToBase64(file);
                                    setPassportGridUrl(base64);
                                    setPassportName(file.name);
                                  }
                                }}
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                              />
                              <Camera className="w-7 h-7 text-indigo-400 mx-auto mb-1.5" />
                              <span className="text-xs font-bold text-slate-300 block">Click to upload photo or take selfie</span>
                              <span className="text-[9px] text-slate-400 block mt-1">Accepts PNG, JPG snapshots</span>
                            </div>
                          )}
                        </div>

                      </div>

                      <button
                        type="button"
                        onClick={handlePassportSubmit}
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition uppercase tracking-wider mt-4 cursor-pointer shadow-lg shadow-indigo-600/20"
                      >
                        Lock Passport Photo & Add to Cart
                      </button>
                    </div>
                  )}

                </div>

                {/* Right Column - Shopping Bag and Checkout Panel */}
                <div className="lg:col-span-4 space-y-6">
                  <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-5 space-y-4 shadow-lg animate-fade-in">
                    <div className="border-b border-white/10 pb-2.5 flex justify-between items-center">
                      <h3 className="font-extrabold text-slate-100 text-xs flex items-center gap-1.5 uppercase">
                        <ShoppingBag className="w-4 h-4 text-indigo-400" />
                        Shopping Bag
                      </h3>
                      <span className="text-[10px] bg-black/20 border border-white/10 px-2 py-0.5 rounded-md font-mono text-slate-300">{cartItems.length} items</span>
                    </div>

                    {cartItems.length === 0 ? (
                      <div className="text-center py-6 text-slate-400 space-y-1.5">
                        <ShoppingBag className="w-6 h-6 mx-auto text-slate-500 mb-1" />
                        <p className="text-[11px] font-bold text-slate-300">Your bag is empty.</p>
                        <p className="text-[9px] text-slate-400">Select a printer utility above to upload and lock documents!</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {cartItems.map((item) => (
                          <div key={item.id} className="p-3 bg-black/20 border border-white/5 rounded-xl space-y-2 text-xs animate-fade-in">
                            <div className="flex justify-between items-start">
                              <span className="font-bold text-slate-300 block max-w-[150px] truncate">{item.label}</span>
                              <span className="font-bold font-mono text-indigo-400">₹{item.price * item.qty}</span>
                            </div>
                            <div className="flex justify-between items-center text-[10px] text-slate-400">
                              <span>{item.specSummary}</span>
                              <button type="button" onClick={() => removeFromCart(item.id)} className="text-rose-400 hover:underline cursor-pointer">Remove</button>
                            </div>
                          </div>
                        ))}

                        {/* Checkout total box */}
                        <div className="border-t border-white/10 pt-3 flex justify-between items-center text-xs">
                          <span className="font-black text-slate-300">Total Price:</span>
                          <span className="font-black font-mono text-indigo-400 text-base">₹{totalFinalPrice}</span>
                        </div>

                        {/* Customer Identification credentials */}
                        <div className="pt-3 border-t border-white/10 space-y-2">
                          <div>
                            <label className="block text-[9px] text-slate-300 font-bold uppercase mb-1">Your Full Name</label>
                            <input 
                              type="text"
                              placeholder="e.g. Rahul Kumar"
                              value={customerName}
                              onChange={(e) => setCustomerName(e.target.value)}
                              className="w-full bg-black/20 border border-white/10 p-2 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] text-slate-300 font-bold uppercase mb-1">Mobile Number (वैकल्पिक)</label>
                            <input 
                              type="tel"
                              placeholder="Your mobile"
                              value={customerMobile}
                              onChange={(e) => setCustomerMobile(e.target.value)}
                              className="w-full bg-black/20 border border-white/10 p-2 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500 font-mono"
                            />
                          </div>
                        </div>

                        {shop.require_prepayment ? (
                          <button
                            type="button"
                            onClick={() => setShowPayModal(true)}
                            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition uppercase tracking-wider flex items-center justify-center gap-1.5 mt-2 cursor-pointer shadow-md shadow-indigo-600/20"
                          >
                            <CreditCard className="w-4.5 h-4.5 text-indigo-200" />
                            Pay UPI & Print (₹{totalFinalPrice})
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={handleQueueCheckout}
                            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition uppercase tracking-wider flex items-center justify-center gap-1.5 mt-2 cursor-pointer shadow-lg shadow-indigo-600/20"
                          >
                            <CheckCircle className="w-4.5 h-4.5 text-indigo-200" />
                            Submit Printing Queue
                          </button>
                        )}

                      </div>
                    )}

                  </div>
                </div>
              </div>
            )}

            </div>
          )}

          {/* UPI PAYMENTS QR SANDBOX MODAL */}
          {showPayModal && (
            <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
              <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl text-center space-y-4 max-w-sm w-full shadow-2xl animate-fade-in">
                <div className="flex justify-between items-center border-b border-white/10 pb-2.5">
                  <span className="font-bold text-xs text-slate-300">Scan & Pay to Store UPI</span>
                  <button type="button" onClick={() => setShowPayModal(false)} className="text-slate-400 hover:text-white p-1 hover:bg-white/10 rounded-lg cursor-pointer"><X className="w-4 h-4" /></button>
                </div>

                <div className="p-4 bg-white rounded-2xl inline-block shadow-inner mx-auto">
                  {qrCodeDataUrl ? (
                    <img src={qrCodeDataUrl} alt="UPI Payment QR Code" className="mx-auto w-[220px] h-[220px]" />
                  ) : (
                    <div className="w-[220px] h-[220px] flex items-center justify-center text-slate-900 bg-slate-100 font-bold text-xs">Generating QR...</div>
                  )}
                </div>

                <div className="text-center font-mono text-xs space-y-1">
                  <span className="text-slate-300 block font-bold">Total Amount: <span className="text-indigo-400 font-extrabold text-sm">₹{totalFinalPrice}</span></span>
                  <span className="text-[10px] text-slate-400 block truncate">UPI ID: {shop?.upi_id}</span>
                </div>

                <p className="text-[10px] text-slate-400 leading-relaxed">Scan this QR code with BHIM, PhonePe, GPay, Paytm, or any UPI app to transfer the payment.</p>

                <button
                  type="button"
                  onClick={handleQueueCheckout}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold rounded-xl transition uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-600/20"
                >
                  <CheckCircle className="w-4.5 h-4.5 text-indigo-200" />
                  Verify Payment & Queue print
                </button>
              </div>
            </div>
          )}

      </main>
    </div>
  );
}
