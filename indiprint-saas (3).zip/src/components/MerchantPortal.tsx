import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { 
  Printer, Smartphone, Settings, RefreshCw, Power, AlertCircle,
  Sliders, Layers, Camera, Check, Clock, Download, X, Eye, Play, Star, Plus, CheckCircle2,
  FileText, ArrowLeft
} from 'lucide-react';
import { Shop, Job, Service } from '../types';

interface MerchantPortalProps {
  onNavigate: (page: 'home' | 'customer' | 'merchant') => void;
}

// Helper to convert hex to RGB
function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : { r: 255, g: 255, b: 255 };
}

// Helper to convert RGB to Hex
function rgbToHex(r: number, g: number, b: number): string {
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

/* ==========================================
   PRINT STUDIO (ADVANCED WORKBENCH) COMPONENT
   ========================================== */
interface PrintStudioProps {
  job: Job;
  onClose: () => void;
  onJobUpdated: () => void;
}

function PrintStudio({ job, onClose, onJobUpdated }: PrintStudioProps) {
  const [activeMode, setActiveMode] = useState<'passport' | 'id_card'>(
    job.service_type === 'id_card' ? 'id_card' : 'passport'
  );
  
  const [selectedUploadIndex, setSelectedUploadIndex] = useState(0);
  const [frontUploadIndex, setFrontUploadIndex] = useState(0);
  const [backUploadIndex, setBackUploadIndex] = useState(1);

  // Passport photo settings
  const [zoom, setZoom] = useState(1.5);
  const [xOffset, setXOffset] = useState(0);
  const [yOffset, setYOffset] = useState(0);
  const [tolerance, setTolerance] = useState(40);
  const [targetRemoveColor, setTargetRemoveColor] = useState('#ffffff');
  const [bgColor, setBgColor] = useState('#2563eb'); // Default beautiful royal blue background
  const [photosCount, setPhotosCount] = useState(8);
  const [borderWidth, setBorderWidth] = useState(1);
  const [isSamplingActive, setIsSamplingActive] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // ID Card setup settings
  const [marginTop, setMarginTop] = useState(15);
  const [cardSpacing, setCardSpacing] = useState(15);
  const [showCutBorder, setShowCutBorder] = useState(true);
  
  const [cardZoomFront, setCardZoomFront] = useState(100);
  const [frontRotation, setFrontRotation] = useState<number>(0);
  const [frontXOffset, setFrontXOffset] = useState(0);
  const [frontYOffset, setFrontYOffset] = useState(0);
  const [frontBrightness, setFrontBrightness] = useState(100);
  const [frontContrast, setFrontContrast] = useState(100);
  const [frontEnhance, setFrontEnhance] = useState<'none' | 'enhance_doc' | 'grayscale'>('none');

  const [cardZoomBack, setCardZoomBack] = useState(100);
  const [backRotation, setBackRotation] = useState<number>(0);
  const [backXOffset, setBackXOffset] = useState(0);
  const [backYOffset, setBackYOffset] = useState(0);
  const [backBrightness, setBackBrightness] = useState(100);
  const [backContrast, setBackContrast] = useState(100);
  const [backEnhance, setBackEnhance] = useState<'none' | 'enhance_doc' | 'grayscale'>('none');

  // Canvas Refs for passport creation
  const singleCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const sheetCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageCacheRef = useRef<HTMLImageElement | null>(null);

  const uploadsList = job.uploads || [];

  // Pre-load current active image
  useEffect(() => {
    if (activeMode === 'passport' && uploadsList[selectedUploadIndex]) {
      setIsProcessing(true);
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = uploadsList[selectedUploadIndex].file_url;
      img.onload = () => {
        imageCacheRef.current = img;
        setIsProcessing(false);
        renderPassportLayouts();
      };
      img.onerror = () => {
        setIsProcessing(false);
      };
    }
  }, [activeMode, selectedUploadIndex, uploadsList]);

  // Re-render passport canvas elements whenever any visual setting parameter is shifted
  useEffect(() => {
    if (activeMode === 'passport' && imageCacheRef.current) {
      renderPassportLayouts();
    }
  }, [activeMode, zoom, xOffset, yOffset, tolerance, targetRemoveColor, bgColor, photosCount, borderWidth]);

  const renderPassportLayouts = () => {
    const img = imageCacheRef.current;
    const singleCanvas = singleCanvasRef.current;
    const sheetCanvas = sheetCanvasRef.current;
    if (!img || !singleCanvas || !sheetCanvas) return;

    // 1. Draw single custom aligned face crop
    const sCtx = singleCanvas.getContext('2d');
    if (!sCtx) return;

    const sW = 260; // 3.5cm matching standard portrait ratio
    const sH = 340; // 4.5cm standard portrait ratio
    singleCanvas.width = sW;
    singleCanvas.height = sH;

    // Drawing onto intermediate canvas to sample / modify background cleanly
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = sW;
    tempCanvas.height = sH;
    const tempCtx = tempCanvas.getContext('2d');
    if (!tempCtx) return;

    // Background Fill
    sCtx.fillStyle = bgColor;
    sCtx.fillRect(0, 0, sW, sH);

    // Calc draw rectangle coordinates
    const srcSize = Math.min(img.width, img.height) / zoom;
    const sx = (img.width / 2) - (srcSize / 2) + xOffset;
    const sy = (img.height / 2) - (srcSize * (sH / sW) / 2) + yOffset;

    tempCtx.drawImage(img, sx, sy, srcSize, srcSize * (sH / sW), 0, 0, sW, sH);

    // Apply Chroma Key logic (background replacement)
    const imgData = tempCtx.getImageData(0, 0, sW, sH);
    const data = imgData.data;
    const tRgb = hexToRgb(targetRemoveColor);
    const repRgb = hexToRgb(bgColor);

    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];

      // Calculate simple color distance
      const dist = Math.sqrt((r - tRgb.r) ** 2 + (g - tRgb.g) ** 2 + (b - tRgb.b) ** 2);
      if (dist <= tolerance) {
        data[i] = repRgb.r;
        data[i + 1] = repRgb.g;
        data[i + 2] = repRgb.b;
      }
    }
    tempCtx.putImageData(imgData, 0, 0);

    // Draw processed image onto final canvas
    sCtx.drawImage(tempCanvas, 0, 0);

    // Stroke border
    if (borderWidth > 0) {
      sCtx.strokeStyle = '#000000';
      sCtx.lineWidth = borderWidth * 2;
      sCtx.strokeRect(0, 0, sW, sH);
    }

    // 2. Draw sheet print grid (4x6 photo sheet)
    const ctx = sheetCanvas.getContext('2d');
    if (!ctx) return;

    const sheetW = 1800; // 4"x6" standard aspect (landscape ratio)
    const sheetH = 1200;
    sheetCanvas.width = sheetW;
    sheetCanvas.height = sheetH;

    // Fill white photo base
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, sheetW, sheetH);

    // Choose grid columns & rows based on package configuration
    let cols = 4;
    let rows = 2;

    if (photosCount === 4) { cols = 2; rows = 2; }
    else if (photosCount === 6) { cols = 3; rows = 2; }
    else if (photosCount === 8) { cols = 4; rows = 2; }
    else if (photosCount === 12) { cols = 4; rows = 3; }
    else if (photosCount === 16) { cols = 4; rows = 4; }

    const gapX = 40;
    const gapY = 40;

    // Compute margins to center grid items beautifully
    const startX = (sheetW - (cols * sW + (cols - 1) * gapX)) / 2;
    const startY = (sheetH - (rows * sH + (rows - 1) * gapY)) / 2;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const px = startX + c * (sW + gapX);
        const py = startY + r * (sH + gapY);
        ctx.drawImage(singleCanvas, px, py);
      }
    }

    // Metadata footer tag
    ctx.fillStyle = '#94a3b8';
    ctx.font = '28px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(
      `IndiPrint Pro Workbench: 4"x6" landscape Photo sheet | ${photosCount} copies arranged`,
      sheetW / 2,
      sheetH - 30
    );
  };

  const handleSingleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isSamplingActive) return;
    const canvas = singleCanvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) * (canvas.width / rect.width));
    const y = Math.floor((e.clientY - rect.top) * (canvas.height / rect.height));

    const ctx = canvas.getContext('2d');
    if (ctx) {
      const pixel = ctx.getImageData(x, y, 1, 1).data;
      const clickedHex = rgbToHex(pixel[0], pixel[1], pixel[2]);
      setTargetRemoveColor(clickedHex);
      setIsSamplingActive(false);
    }
  };

  const handlePrintTrigger = (layoutId: string) => {
    const style = document.createElement('style');
    style.id = 'dynamic-direct-print-layout';
    style.innerHTML = `
      @media print {
        body * {
          visibility: hidden !important;
          height: 0 !important;
          overflow: hidden !important;
        }
        #${layoutId}, #${layoutId} * {
          visibility: visible !important;
          height: auto !important;
          overflow: visible !important;
        }
        #${layoutId} {
          position: absolute !important;
          left: 0 !important;
          top: 0 !important;
          width: 100% !important;
          height: 100% !important;
        }
      }
    `;
    document.head.appendChild(style);
    window.print();
    setTimeout(() => {
      const el = document.getElementById('dynamic-direct-print-layout');
      if (el) el.remove();
    }, 1000);
  };

  const bgPresets = [
    { name: 'Sky Blue (लाइट स्काई)', hex: '#a5f3fc' },
    { name: 'Royal Blue (रॉयल ब्लू)', hex: '#2563eb' },
    { name: 'Pure White (सफ़ेद)', hex: '#ffffff' },
    { name: 'Light Gray (लाइट ग्रे)', hex: '#f1f5f9' },
    { name: 'Red (लाल)', hex: '#ef4444' }
  ];

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 overflow-y-auto p-4 md:p-6 flex flex-col">
      
      {/* Studio Header (hidden in print) */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-white/10 pb-4 mb-4 shrink-0 print:hidden gap-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-black text-slate-100 uppercase tracking-wider">IndiPrint Advanced Workbench</h2>
            <p className="text-[10px] text-slate-300 font-medium">Order: {job.id} for {job.customer_name} | Service: <span className="uppercase text-indigo-400 font-extrabold">{job.service_type}</span></p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Mode Selection */}
          <div className="bg-black/20 border border-white/10 p-1 rounded-xl flex gap-1 mr-1">
            <button
              type="button"
              onClick={() => setActiveMode('passport')}
              className={`flex items-center gap-1.5 py-1 px-3 rounded-lg text-[10px] font-bold transition cursor-pointer ${activeMode === 'passport' ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/20 shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <Camera className="w-3 h-3" />
              Passport (4x6 Sheet)
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveMode('id_card');
                if (uploadsList.length > 1) {
                  setFrontUploadIndex(0);
                  setBackUploadIndex(1);
                } else {
                  setFrontUploadIndex(0);
                  setBackUploadIndex(0);
                }
              }}
              className={`flex items-center gap-1.5 py-1 px-3 rounded-lg text-[10px] font-bold transition cursor-pointer ${activeMode === 'id_card' ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/20 shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <Layers className="w-3 h-3" />
              ID Xerox (A4 Sheet)
            </button>
          </div>

          {activeMode === 'passport' ? (
            <button
              type="button"
              onClick={() => handlePrintTrigger('passport-printable-target-sheet')}
              className="py-2 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20"
            >
              <Printer className="w-4 h-4" />
              Print Passport (4"x6")
            </button>
          ) : (
            <button
              type="button"
              onClick={() => handlePrintTrigger('id-card-printable-target-sheet')}
              className="py-2 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20"
            >
              <Printer className="w-4 h-4" />
              Print Xerox (A4)
            </button>
          )}
          
          <button
            type="button"
            onClick={onClose}
            className="p-2 hover:bg-white/10 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-0 print:block">
        
        {/* Sidebar Controls Panel (hidden in print) */}
        <div className="lg:col-span-4 bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-4 space-y-4 overflow-y-auto no-scrollbar print:hidden max-h-[80vh] shadow-xl">
          
          {/* Uploaded Customer Files picker */}
          <div>
            <span className="block text-[10px] font-extrabold text-slate-300 uppercase tracking-widest mb-2.5">Uploaded Order Attachments ({uploadsList.length})</span>
            <div className="space-y-1.5">
              {uploadsList.map((upload, idx) => (
                <button
                  key={upload.id || idx}
                  type="button"
                  onClick={() => {
                    if (activeMode === 'passport') {
                      setSelectedUploadIndex(idx);
                    } else {
                      setFrontUploadIndex(idx);
                    }
                  }}
                  className={`w-full p-2.5 rounded-xl border text-left text-xs transition flex items-center justify-between gap-2 overflow-hidden cursor-pointer ${
                    (activeMode === 'passport' && selectedUploadIndex === idx) || (activeMode === 'id_card' && frontUploadIndex === idx)
                      ? 'bg-indigo-600/10 border-indigo-500/30 text-indigo-200'
                      : 'bg-black/20 border-white/5 hover:bg-white/5 text-slate-400'
                  }`}
                >
                  <div className="flex items-center gap-2 overflow-hidden truncate">
                    <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                    <div className="truncate">
                      <span className="font-bold block truncate max-w-[200px] text-slate-200">{upload.file_name || `File ${idx+1}`}</span>
                      <span className="text-[10px] text-slate-400 truncate block">File Index {idx + 1}</span>
                    </div>
                  </div>

                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/5 border border-white/10 text-indigo-300 shrink-0">Selected</span>
                </button>
              ))}
            </div>
          </div>

          {/* Passport mode controls */}
          {activeMode === 'passport' && uploadsList[selectedUploadIndex] && (
            <div className="space-y-4">
              <div className="bg-black/20 border border-white/5 rounded-xl p-3 space-y-3">
                <span className="block text-[10px] font-bold text-indigo-400 uppercase tracking-wide border-b border-white/5 pb-1 flex items-center gap-1">
                  <Sliders className="w-3.5 h-3.5" /> Cropping & Face Alignment (फ़ोटो अलाइनमेंट)
                </span>
                
                <div className="space-y-2 pt-1 text-[10px]">
                  <div>
                    <div className="flex justify-between text-slate-300 mb-0.5">
                      <span>Face Zoom (ज़ूम)</span>
                      <span className="font-mono">{zoom.toFixed(1)}x</span>
                    </div>
                    <input 
                      type="range" 
                      min="0.5" 
                      max="3.0" 
                      step="0.05"
                      value={zoom}
                      onChange={(e) => setZoom(parseFloat(e.target.value))}
                      className="w-full accent-teal-500" 
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-400 mb-0.5">
                      <span>Horizontal Shift (लेफ्ट/राइट)</span>
                      <span className="font-mono">{xOffset}px</span>
                    </div>
                    <input 
                      type="range" 
                      min="-500" 
                      max="500" 
                      step="2"
                      value={xOffset}
                      onChange={(e) => setXOffset(parseInt(e.target.value))}
                      className="w-full accent-teal-500" 
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-400 mb-0.5">
                      <span>Vertical Shift (ऊपर/नीचे)</span>
                      <span className="font-mono">{yOffset}px</span>
                    </div>
                    <input 
                      type="range" 
                      min="-500" 
                      max="500" 
                      step="2"
                      value={yOffset}
                      onChange={(e) => setYOffset(parseInt(e.target.value))}
                      className="w-full accent-teal-500" 
                    />
                  </div>
                </div>
              </div>

              {/* BG swap */}
              <div className="bg-black/20 border border-white/5 rounded-xl p-3 space-y-3">
                <span className="block text-[10px] font-bold text-indigo-400 uppercase tracking-wide border-b border-white/5 pb-1 flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 text-indigo-400" /> Chroma Key BG Removal (बैकग्राउंड बदलें)
                </span>
                <p className="text-[9px] text-slate-300">Select background color in original picture to swap it:</p>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsSamplingActive(!isSamplingActive)}
                    className={`flex-1 py-1.5 px-2.5 text-[9px] rounded-lg transition-all font-black flex items-center justify-center gap-1.5 border cursor-pointer ${
                      isSamplingActive 
                        ? 'bg-indigo-600/25 border-indigo-500 text-indigo-300' 
                        : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <Sliders className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    {isSamplingActive ? '🎯 Click on face preview' : '🔍 Color Dropper'}
                  </button>
                  
                  <div className="flex items-center gap-1 shrink-0 bg-black/20 px-2 py-1 border border-white/10 rounded-lg">
                    <span className="text-[9px] text-slate-400">Key:</span>
                    <input 
                      type="color" 
                      value={targetRemoveColor} 
                      onChange={(e) => setTargetRemoveColor(e.target.value)} 
                      className="w-4 h-4 rounded border-0 bg-transparent cursor-pointer"
                    />
                  </div>
                </div>

                <div className="space-y-1 text-[10px]">
                  <div className="flex justify-between text-slate-300">
                    <span>Remove Sensitivity</span>
                    <span className="font-mono">{tolerance}</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="150" 
                    step="1"
                    value={tolerance}
                    onChange={(e) => setTolerance(parseInt(e.target.value))}
                    className="w-full accent-indigo-500" 
                  />
                </div>

                <div>
                  <span className="block text-[9px] font-bold text-slate-300 mb-1.5 uppercase">New Target Background Color:</span>
                  <div className="grid grid-cols-2 gap-1.5 text-[9px]">
                    {bgPresets.map((preset) => (
                      <button
                        key={preset.hex}
                        type="button"
                        onClick={() => setBgColor(preset.hex)}
                        className={`flex items-center gap-1.5 p-1 rounded-lg border text-left font-semibold cursor-pointer ${
                          bgColor === preset.hex 
                            ? 'bg-indigo-500/10 border-indigo-500 text-indigo-400' 
                            : 'bg-white/5 border-white/10 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <div className="w-3 h-3 rounded border border-slate-700 shrink-0" style={{ backgroundColor: preset.hex }} />
                        <span className="truncate">{preset.name}</span>
                      </button>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between p-1 px-2.5 bg-black/20 border border-white/10 rounded-lg mt-2 text-[9px]">
                    <span className="text-slate-400">Custom Solid Hex:</span>
                    <input 
                      type="color" 
                      value={bgColor} 
                      onChange={(e) => setBgColor(e.target.value)} 
                      className="w-4 h-4 rounded border-0 bg-transparent cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Photo copy count options */}
              <div className="bg-black/20 border border-white/5 rounded-xl p-3 space-y-3">
                <span className="block text-[10px] font-bold text-slate-300 uppercase tracking-wide border-b border-white/5 pb-1">
                  4x6 Print Layout Copies (प्रिंट संख्या)
                </span>

                <div className="grid grid-cols-5 gap-1.5">
                  {[4, 6, 8, 12, 16].map((count) => (
                    <button
                      key={count}
                      type="button"
                      onClick={() => setPhotosCount(count)}
                      className={`py-1.5 rounded-lg text-xs font-black border text-center transition cursor-pointer ${
                        photosCount === count 
                          ? 'bg-indigo-600 border-indigo-500 text-white' 
                          : 'bg-white/5 border-white/10 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {count} P
                    </button>
                  ))}
                </div>

                <div className="space-y-1.5 pt-1 text-[10px]">
                  <div className="flex justify-between text-slate-300">
                    <span>Border Line Stroke</span>
                    <span className="font-mono">{borderWidth}px</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="5" 
                    step="1"
                    value={borderWidth}
                    onChange={(e) => setBorderWidth(parseInt(e.target.value))}
                    className="w-full accent-indigo-500" 
                  />
                </div>
              </div>
            </div>
          )}

          {/* ID Card controls */}
          {activeMode === 'id_card' && (
            <div className="space-y-4">
              <div className="space-y-1 bg-black/20 border border-white/5 p-3 rounded-xl">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest border-b border-slate-800 pb-1.5 flex items-center justify-between">
                  <span>📐 Layout Settings</span>
                  <span className="text-[9px] text-teal-400">Standard A4</span>
                </h3>
                
                <div className="grid grid-cols-2 gap-3 text-[10px] pt-2">
                  <div>
                    <span className="block text-slate-400 font-semibold mb-1">Top Margin: {marginTop}mm</span>
                    <input 
                      type="range" 
                      min="5" 
                      max="100" 
                      value={marginTop}
                      onChange={(e) => setMarginTop(parseInt(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                  <div>
                    <span className="block text-slate-400 font-semibold mb-1">Card Spacing: {cardSpacing}mm</span>
                    <input 
                      type="range" 
                      min="5" 
                      max="60" 
                      value={cardSpacing}
                      onChange={(e) => setCardSpacing(parseInt(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-[10px] text-slate-400 font-semibold">Show Outer Cut Border</span>
                  <input 
                    type="checkbox" 
                    checked={showCutBorder}
                    onChange={(e) => setShowCutBorder(e.target.checked)}
                    className="w-4 h-4 accent-teal-500 rounded cursor-pointer"
                  />
                </div>
              </div>

              {/* Front Side Control Card */}
              <div className="bg-black/20 border border-white/5 rounded-xl p-3 space-y-3">
                <span className="block text-[10px] font-black text-indigo-400 uppercase tracking-wider border-b border-white/5 pb-1 flex items-center justify-between">
                  <span>Front Side Layout (पहला साइड)</span>
                  <span className="text-[8px] bg-indigo-500/10 px-1 py-0.5 rounded text-indigo-400 font-mono">Front</span>
                </span>

                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <span className="block text-slate-300 mb-0.5 font-semibold">Zoom: {cardZoomFront}%</span>
                    <input 
                      type="range" 
                      min="50" 
                      max="250" 
                      value={cardZoomFront}
                      onChange={(e) => setCardZoomFront(parseInt(e.target.value))}
                      className="w-full accent-indigo-500"
                    />
                  </div>
                  <div>
                    <span className="block text-slate-300 mb-0.5 font-semibold">Rotation: {frontRotation}°</span>
                    <div className="grid grid-cols-4 gap-1">
                      {[0, 90, 180, 270].map((deg) => (
                        <button
                          key={deg}
                          type="button"
                          onClick={() => setFrontRotation(deg)}
                          className={`py-0.5 text-[9px] font-bold rounded border cursor-pointer ${frontRotation === deg ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40' : 'bg-white/5 border-white/10 text-slate-400'}`}
                        >
                          {deg}°
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <span className="block text-slate-300 mb-0.5 font-semibold">Crop X: {frontXOffset}px</span>
                    <input 
                      type="range" 
                      min="-150" 
                      max="150" 
                      value={frontXOffset}
                      onChange={(e) => setFrontXOffset(parseInt(e.target.value))}
                      className="w-full accent-indigo-500"
                    />
                  </div>
                  <div>
                    <span className="block text-slate-300 mb-0.5 font-semibold">Crop Y: {frontYOffset}px</span>
                    <input 
                      type="range" 
                      min="-150" 
                      max="150" 
                      value={frontYOffset}
                      onChange={(e) => setFrontYOffset(parseInt(e.target.value))}
                      className="w-full accent-indigo-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <span className="block text-slate-300 mb-0.5 font-semibold">Brightness: {frontBrightness}%</span>
                    <input 
                      type="range" 
                      min="50" 
                      max="200" 
                      value={frontBrightness}
                      onChange={(e) => setFrontBrightness(parseInt(e.target.value))}
                      className="w-full accent-indigo-500"
                    />
                  </div>
                  <div>
                    <span className="block text-slate-300 mb-0.5 font-semibold">Contrast: {frontContrast}%</span>
                    <input 
                      type="range" 
                      min="50" 
                      max="200" 
                      value={frontContrast}
                      onChange={(e) => setFrontContrast(parseInt(e.target.value))}
                      className="w-full accent-indigo-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-1 pt-1">
                  {[
                    { id: 'none', label: 'Original' },
                    { id: 'enhance_doc', label: 'Crisp Doc' },
                    { id: 'grayscale', label: 'B/W Gray' }
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setFrontEnhance(opt.id as any)}
                      className={`py-0.5 text-[8.5px] font-bold rounded border cursor-pointer ${frontEnhance === opt.id ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40' : 'bg-white/5 border-white/10 text-slate-400'}`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Back Side Control Card */}
              <div className="bg-black/20 border border-white/5 rounded-xl p-3 space-y-3">
                <div className="flex justify-between items-center border-b border-white/5 pb-1">
                  <span className="block text-[10px] font-black text-indigo-400 uppercase tracking-wider">
                    Back Side Layout (दूसरा साइड)
                  </span>
                  <select 
                    value={backUploadIndex} 
                    onChange={(e) => setBackUploadIndex(Number(e.target.value))}
                    className="bg-black/40 border border-white/10 text-[9px] text-slate-200 rounded px-1 cursor-pointer focus:outline-none"
                  >
                    {uploadsList.map((_, idx) => (
                      <option key={idx} value={idx}>File {idx + 1}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <span className="block text-slate-400 mb-0.5 font-semibold">Zoom: {cardZoomBack}%</span>
                    <input 
                      type="range" 
                      min="50" 
                      max="250" 
                      value={cardZoomBack}
                      onChange={(e) => setCardZoomBack(parseInt(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                  <div>
                    <span className="block text-slate-400 mb-0.5 font-semibold">Rotation: {backRotation}°</span>
                    <div className="grid grid-cols-4 gap-1">
                      {[0, 90, 180, 270].map((deg) => (
                        <button
                          key={deg}
                          type="button"
                          onClick={() => setBackRotation(deg)}
                          className={`py-0.5 text-[9px] font-bold rounded border cursor-pointer ${backRotation === deg ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-slate-900 border-slate-800 text-slate-500'}`}
                        >
                          {deg}°
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <span className="block text-slate-400 mb-0.5 font-semibold">Crop X: {backXOffset}px</span>
                    <input 
                      type="range" 
                      min="-150" 
                      max="150" 
                      value={backXOffset}
                      onChange={(e) => setBackXOffset(parseInt(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                  <div>
                    <span className="block text-slate-400 mb-0.5 font-semibold">Crop Y: {backYOffset}px</span>
                    <input 
                      type="range" 
                      min="-150" 
                      max="150" 
                      value={backYOffset}
                      onChange={(e) => setBackYOffset(parseInt(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <span className="block text-slate-400 mb-0.5 font-semibold">Brightness: {backBrightness}%</span>
                    <input 
                      type="range" 
                      min="50" 
                      max="200" 
                      value={backBrightness}
                      onChange={(e) => setBackBrightness(parseInt(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                  <div>
                    <span className="block text-slate-400 mb-0.5 font-semibold">Contrast: {backContrast}%</span>
                    <input 
                      type="range" 
                      min="50" 
                      max="200" 
                      value={backContrast}
                      onChange={(e) => setBackContrast(parseInt(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-1 pt-1">
                  {[
                    { id: 'none', label: 'Original' },
                    { id: 'enhance_doc', label: 'Crisp Doc' },
                    { id: 'grayscale', label: 'B/W Gray' }
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setBackEnhance(opt.id as any)}
                      className={`py-0.5 text-[8.5px] font-bold rounded border cursor-pointer ${backEnhance === opt.id ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-slate-900 border-slate-800 text-slate-500'}`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Print canvas preview section */}
        <div className="lg:col-span-8 flex justify-center bg-slate-950 border border-slate-900 rounded-3xl p-6 overflow-y-auto no-scrollbar print:p-0 print:border-none print:bg-white items-center">
          
          {/* Passport Mode Canvas Sheet */}
          {activeMode === 'passport' && uploadsList[selectedUploadIndex] && (
            <div className="w-full space-y-6 flex flex-col items-center animate-fade-in">
              
              {/* Side-by-side single photo & instructions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full max-w-lg items-end">
                
                {/* Single Photo zoom frame */}
                <div className="flex flex-col items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block text-center">Face Crop Canvas</span>
                  <div className="relative p-1.5 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow">
                    {isProcessing && (
                      <div className="absolute inset-0 bg-slate-950/80 flex items-center justify-center text-xs text-slate-400">Loading...</div>
                    )}
                    <canvas
                      ref={singleCanvasRef}
                      onClick={handleSingleCanvasClick}
                      className={`w-[130px] h-[167px] bg-slate-800 rounded-lg cursor-crosshair border ${
                        isSamplingActive ? 'ring-2 ring-amber-500 animate-pulse' : 'border-slate-850'
                      }`}
                      title="Click to pick solid background removal coordinate"
                    />
                  </div>
                  <span className="text-[9px] text-slate-500 block text-center">Click pixel to auto-key background</span>
                </div>

                {/* Mini instruction tip box */}
                <div className="bg-slate-900 border border-slate-850 p-3 rounded-2xl text-[10px] text-slate-400 space-y-1">
                  <span className="font-extrabold text-slate-200 block">💡 Pro Guide:</span>
                  <p>1. If customer uploaded standard selfie, use droppers or presets onto background pixels.</p>
                  <p>2. Adjust <strong>Face Zoom</strong> and vertical offsets until head aligns correctly.</p>
                  <p>3. Border is drawn inside. Click top Print button to send to spooler.</p>
                </div>
              </div>

              {/* 4x6 Printable Grid Sheet Viewport */}
              <div className="flex flex-col items-center gap-2.5 w-full">
                <div className="flex items-center justify-between w-full max-w-md text-[10px] font-extrabold uppercase text-slate-400">
                  <span className="flex items-center gap-1"><Printer className="w-3.5 h-3.5" /> 4"x6" Photo Sheet Layout (4R Landscape)</span>
                  <span className="text-teal-400">Ready to print</span>
                </div>

                {/* Physical 3:2 canvas container represented mathematically */}
                <div className="border border-slate-800 bg-slate-900 p-3 rounded-2xl shadow-xl max-w-md w-full">
                  <div className="overflow-hidden bg-white rounded-md aspect-[3/2] flex items-center justify-center relative">
                    <div id="passport-printable-target-sheet" className="w-full h-full">
                      <canvas
                        ref={sheetCanvasRef}
                        className="w-full h-full object-contain"
                      />
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* ID Card Mode Viewport */}
          {activeMode === 'id_card' && (
            <div 
              id="id-card-printable-target-sheet"
              className="bg-white text-slate-950 shadow-2xl relative select-none shrink-0 mx-auto"
              style={{
                width: '210mm',
                height: '297mm',
                padding: '10mm',
                boxSizing: 'border-box',
                pageBreakAfter: 'always'
              }}
            >
              {/* Visual A4 Grid Top Spacing Helper */}
              <div style={{ height: `${marginTop}mm` }} className="print:hidden border-b border-dashed border-red-300/45 text-center flex items-center justify-center text-[9px] text-red-400/60 font-semibold mb-2">
                Top Margin Gap Offset: {marginTop}mm
              </div>

              {/* ID Cards Layout Box */}
              <div 
                className="flex flex-col items-center justify-start w-full"
                style={{ gap: `${cardSpacing}mm` }}
              >
                
                {/* Card Front */}
                {uploadsList[frontUploadIndex] && (
                  <div 
                    className="relative overflow-hidden shrink-0 bg-slate-100"
                    style={{
                      width: '85.6mm',
                      height: '53.98mm',
                      borderRadius: '3.18mm',
                      border: showCutBorder ? '0.4mm solid #475569' : 'none'
                    }}
                  >
                    <img 
                      src={uploadsList[frontUploadIndex].file_url}
                      alt="Front ID Card"
                      className="object-cover max-w-none w-full h-full"
                      style={{
                        width: `${cardZoomFront}%`,
                        height: `${cardZoomFront}%`,
                        transform: `translate(${frontXOffset}px, ${frontYOffset}px) rotate(${frontRotation}deg)`,
                        filter: `brightness(${frontBrightness}%) contrast(${frontContrast}%) ${frontEnhance === 'enhance_doc' ? 'contrast(175%) grayscale(100%)' : frontEnhance === 'grayscale' ? 'grayscale(100%)' : ''}`
                      }}
                    />
                    <div className="absolute top-1 left-2 bg-slate-950/70 text-white font-extrabold text-[8px] uppercase px-1 rounded select-none print:hidden">
                      Front Card Setup
                    </div>
                  </div>
                )}

                {/* Card Back */}
                {uploadsList[backUploadIndex] && (
                  <div 
                    className="relative overflow-hidden shrink-0 bg-slate-100"
                    style={{
                      width: '85.6mm',
                      height: '53.98mm',
                      borderRadius: '3.18mm',
                      border: showCutBorder ? '0.4mm solid #475569' : 'none'
                    }}
                  >
                    <img 
                      src={uploadsList[backUploadIndex].file_url}
                      alt="Back ID Card"
                      className="object-cover max-w-none w-full h-full"
                      style={{
                        width: `${cardZoomBack}%`,
                        height: `${cardZoomBack}%`,
                        transform: `translate(${backXOffset}px, ${backYOffset}px) rotate(${backRotation}deg)`,
                        filter: `brightness(${backBrightness}%) contrast(${backContrast}%) ${backEnhance === 'enhance_doc' ? 'contrast(175%) grayscale(100%)' : backEnhance === 'grayscale' ? 'grayscale(100%)' : ''}`
                      }}
                    />
                    <div className="absolute top-1 left-2 bg-slate-950/70 text-white font-extrabold text-[8px] uppercase px-1 rounded select-none print:hidden">
                      Back Card Setup
                    </div>
                  </div>
                )}

              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}

/* ====================================
   MAIN MERCHANT PORTAL MAIN COMPONENT
   ==================================== */
export default function MerchantPortal({ onNavigate }: MerchantPortalProps) {
  const [activeTab, setActiveTab] = useState('queue');
  const [isRegistering, setIsRegistering] = useState(false);
  const [currentUser, setCurrentUser] = useState<Shop | null>(null);

  // Auth form fields
  const [mobile, setMobile] = useState('');
  const [shopName, setShopName] = useState('');
  const [password, setPassword] = useState('');
  const [upiId, setUpiId] = useState('');
  const [authError, setAuthError] = useState('');

  // Data states
  const [jobs, setJobs] = useState<Job[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [queueFilter, setQueueFilter] = useState<'all' | 'PENDING' | 'PROCESSING' | 'PRINTED'>('all');
  const [activeStudioJob, setActiveStudioJob] = useState<Job | null>(null);
  
  const [bannerQrCodeUrl, setBannerQrCodeUrl] = useState('');
  const [copiedAgent, setCopiedAgent] = useState(false);

  useEffect(() => {
    // Retrieve session if exists
    const cachedUser = sessionStorage.getItem('indiprint_owner');
    if (cachedUser) {
      setCurrentUser(JSON.parse(cachedUser));
    }
  }, []);

  useEffect(() => {
    let interval: any;
    if (currentUser) {
      fetchJobsAndServices();
      interval = setInterval(fetchJobsAndServices, 6000);
    }
    return () => clearInterval(interval);
  }, [currentUser]);

  // Generate dynamic QR code poster for customers
  useEffect(() => {
    if (currentUser && activeTab === 'banner') {
      const targetUrl = `${window.location.origin}/customer?shop=${currentUser.mobile}`;
      QRCode.toDataURL(targetUrl, { width: 280, margin: 1 })
        .then(url => {
          setBannerQrCodeUrl(url);
        })
        .catch(err => {
          console.error('Failed to generate store banner QR code:', err);
        });
    }
  }, [currentUser, activeTab]);

  const fetchJobsAndServices = async () => {
    if (!currentUser) return;
    try {
      const jobsRes = await fetch(`/api/jobs/shop/${currentUser.id}`);
      if (jobsRes.ok) {
        const jobsData = await jobsRes.json();
        setJobs(jobsData);
      }
      const svcRes = await fetch(`/api/services/${currentUser.id}`);
      if (svcRes.ok) {
        const servicesData = await svcRes.json();
        setServices(servicesData);
      }
    } catch (err) {
      console.error('Failed fetching server queue', err);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!mobile || !shopName || !password || !upiId) {
      setAuthError('All parameters are required.');
      return;
    }
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobile, shop_name: shopName, password, upi_id: upiId })
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Failed to register.');
      } else {
        setCurrentUser(data.user);
        sessionStorage.setItem('indiprint_owner', JSON.stringify(data.user));
      }
    } catch (err) {
      setAuthError('Connection error.');
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!mobile || !password) {
      setAuthError('Please input both mobile and password.');
      return;
    }
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobile, password })
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Invalid credentials.');
      } else {
        setCurrentUser(data.user);
        sessionStorage.setItem('indiprint_owner', JSON.stringify(data.user));
      }
    } catch (err) {
      setAuthError('Connection error.');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    sessionStorage.removeItem('indiprint_owner');
  };

  const updateJobStatus = async (jobId: string, status: string) => {
    try {
      const res = await fetch(`/api/jobs/${jobId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        fetchJobsAndServices();
      }
    } catch (err) {
      console.error('Failed syncing job update', err);
    }
  };

  const updateJobPayment = async (jobId: string, payment_status: string) => {
    try {
      const res = await fetch(`/api/jobs/${jobId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payment_status })
      });
      if (res.ok) {
        fetchJobsAndServices();
      }
    } catch (err) {
      console.error('Failed syncing payment update', err);
    }
  };

  const updateServicesPricing = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/services/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: currentUser?.id, services })
      });
      if (res.ok) {
        alert('Pricing services saved and live!');
        fetchJobsAndServices();
      }
    } catch (err) {
      alert('Failed saving prices.');
    }
  };

  const handlePriceChange = (id: string, field: string, value: any) => {
    setServices(prev => prev.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const agentCodeString = currentUser ? `/**
 * IndiPrint Auto-Printing Agent Service
 * Save this file as "print-agent.mjs" (ES Module) or "print-agent.js"
 * Run on your store's Windows/PC: "node print-agent.js"
 */

import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';

const CONFIG = {
  shopMobile: "${currentUser.mobile}",
  serverUrl: "${window.location.origin}",
  pollIntervalMs: 5000, 
  downloadFolder: "./printed_jobs"
};

if (!fs.existsSync(CONFIG.downloadFolder)) {
  fs.mkdirSync(CONFIG.downloadFolder, { recursive: true });
}

console.log("====================================================");
console.log("🟢 IndiPrint Auto-Print Service Started Successfully");
console.log(\`🛒 Active Shop Mobile : \${CONFIG.shopMobile}\`);
console.log(\`🌐 SaaS Server Host   : \${CONFIG.serverUrl}\`);
console.log("====================================================");

async function checkAndPrintJobs() {
  const pollUrl = \`\${CONFIG.serverUrl}/api/jobs/agent-stream?shop_mobile=\${CONFIG.shopMobile}\`;
  
  try {
    const res = await fetch(pollUrl);
    if (!res.ok) {
      console.warn("⚠️ API handshake issue. Reconnecting...");
      return;
    }
    const jobs = await res.json();
    
    if (jobs && jobs.length > 0) {
      console.log(\`\${jobs.length} new PDF/ID/Photo jobs found in queue...\`);
      
      for (const job of jobs) {
        console.log(\`Processing Order Token: \${job.id} for \${job.customer_name}\`);
        await updateJobStatus(job.id, 'PROCESSING');
        
        if (job.uploads && job.uploads.length > 0) {
          for (const upload of job.uploads) {
            const fileName = \`\${job.id}_\${upload.file_name}\`;
            const downloadPath = path.join(CONFIG.downloadFolder, fileName);
            const fileUrl = \`\${CONFIG.serverUrl}\${upload.file_url}\`;
            
            console.log(\`Downloading: \${upload.file_name}...\`);
            const fileRes = await fetch(fileUrl);
            const buffer = await fileRes.buffer();
            fs.writeFileSync(downloadPath, buffer);
            
            await runLocalPrintCommand(downloadPath, upload.file_type);
          }
        }
        await updateJobStatus(job.id, 'PRINTED');
      }
    }
  } catch (error) {
    console.error("Connection issue, retrying in 5s...", error.message);
  }
}

async function updateJobStatus(jobId, status) {
  try {
    await fetch(\`\${CONFIG.serverUrl}/api/jobs/\${jobId}\`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
  } catch (err) {
    console.error("Failed to update status:", err.message);
  }
}

function runLocalPrintCommand(filePath, fileType) {
  return new Promise((resolve) => {
    console.log(\`Sending "\${filePath}" to spool...\`);
    const isWin = process.platform === "win32";
    const command = isWin 
      ? \`powershell -Command "Start-Process -FilePath '\${filePath}' -Verb Print -PassThru | % { $_.CloseMainWindow(); Stop-Process $_ }"\`
      : \`lp "\${filePath}"\`;
      
    exec(command, (error, stdout, stderr) => {
      resolve();
    });
  });
}

setInterval(checkAndPrintJobs, CONFIG.pollIntervalMs);
checkAndPrintJobs();
` : '';

  const copyAgentCodeToClipboard = () => {
    navigator.clipboard.writeText(agentCodeString);
    setCopiedAgent(true);
    setTimeout(() => setCopiedAgent(false), 2000);
  };

  const downloadAgentFile = () => {
    const blob = new Blob([agentCodeString], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'print-agent.js';
    link.click();
  };

  // Filter jobs
  const filteredJobs = jobs.filter(j => queueFilter === 'all' || j.status === queueFilter);

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-indigo-500/30 selection:text-indigo-200">
        
        {/* Header */}
        <header className="bg-slate-900/60 backdrop-blur border-b border-slate-800/80 sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
            <button 
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2.5 hover:opacity-90 transition text-left cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-emerald-500 flex items-center justify-center text-white font-extrabold shadow-md">
                <Printer className="w-5.5 h-5.5 text-white" />
              </div>
              <div>
                <span className="font-black text-lg tracking-tight bg-gradient-to-r from-slate-100 to-slate-300 bg-clip-text text-transparent">IndiPrint</span>
                <span className="text-[10px] text-emerald-400 block font-bold tracking-widest uppercase -mt-1 font-mono">Merchant Portal</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('home')}
              className="px-3.5 py-1.5 text-xs font-bold text-slate-400 hover:text-slate-100 flex items-center gap-1.5 cursor-pointer bg-slate-900 border border-slate-800 rounded-xl"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </button>
          </div>
        </header>

        {/* Auth Forms */}
        <div className="max-w-md mx-auto my-12 bg-white/5 border border-white/10 backdrop-blur-xl p-8 rounded-3xl shadow-2xl w-full animate-fade-in">
          <div className="text-center mb-6">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-extrabold mx-auto shadow-md mb-2 shadow-indigo-600/20">
              <Printer className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-black text-white">Xerox Store Login</h2>
            <p className="text-xs text-slate-300 mt-1">Access your store's digital print queue, custom editor & setups</p>
          </div>

          {authError && (
            <div className="p-3 bg-rose-950/40 border border-rose-500/20 text-rose-200 text-xs rounded-xl flex items-center gap-2 mb-4 animate-fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{authError}</span>
            </div>
          )}

          {isRegistering ? (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] text-slate-300 font-bold uppercase mb-1">Shop Name (दुकान का नाम)</label>
                <input 
                  type="text" 
                  placeholder="e.g. Royal Xerox & Prints"
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  className="w-full bg-black/20 border border-white/10 px-3.5 py-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-300 font-bold uppercase mb-1">Mobile Number (लॉगिन मोबाइल)</label>
                <input 
                  type="tel" 
                  placeholder="10 digit mobile"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  className="w-full bg-black/20 border border-white/10 px-3.5 py-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-300 font-bold uppercase mb-1">Password (पासवर्ड)</label>
                <input 
                  type="password" 
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-black/20 border border-white/10 px-3.5 py-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-300 font-bold uppercase mb-1">UPI ID for Customer Payment</label>
                <input 
                  type="text" 
                  placeholder="e.g. shopowner@okaxis"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full bg-black/20 border border-white/10 px-3.5 py-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition uppercase tracking-wider cursor-pointer shadow-lg shadow-indigo-600/20"
              >
                Create Shop Portal
              </button>

              <p className="text-center text-[11px] text-slate-300">
                Already have a shop?{' '}
                <button type="button" onClick={() => { setIsRegistering(false); setAuthError(''); }} className="text-indigo-400 hover:underline font-bold cursor-pointer">
                  Login here
                </button>
              </p>
            </form>
          ) : (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] text-slate-300 font-bold uppercase mb-1">Store Registered Mobile</label>
                <input 
                  type="tel" 
                  placeholder="Registered mobile"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  className="w-full bg-black/20 border border-white/10 px-3.5 py-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-300 font-bold uppercase mb-1">Security Password</label>
                <input 
                  type="password" 
                  placeholder="Your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-black/20 border border-white/10 px-3.5 py-2.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition uppercase tracking-wider cursor-pointer shadow-lg shadow-indigo-600/20"
              >
                Log In
              </button>

              <p className="text-center text-[11px] text-slate-300">
                New Xerox store?{' '}
                <button type="button" onClick={() => { setIsRegistering(true); setAuthError(''); }} className="text-indigo-400 hover:underline font-bold cursor-pointer">
                  Register store here
                </button>
              </p>
            </form>
          )}
        </div>

        <footer className="py-6 border-t border-slate-800 text-center text-[10px] text-slate-500">
          <p>IndiPrint SaaS System Workspace v1.4</p>
        </footer>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-6 animate-fade-in">
      
      {/* Header Bar */}
      <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-black shadow-md shadow-indigo-600/20">
            <Printer className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-extrabold text-base text-slate-100">{currentUser.shop_name}</h1>
            <p className="text-xs text-slate-300 flex items-center gap-1.5 mt-0.5">
              <span className="inline-block w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
              Mobile Queue: <span className="font-mono text-indigo-400 font-bold">{currentUser.mobile}</span>
              <span className="text-slate-500">|</span>
              UPI ID: <span className="text-slate-300 font-semibold">{currentUser.upi_id}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={fetchJobsAndServices}
            className="p-2.5 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-300 hover:text-white rounded-xl transition cursor-pointer"
            title="Sync queue"
          >
            <RefreshCw className="w-4.5 h-4.5" />
          </button>
          <button
            type="button"
            onClick={handleLogout}
            className="py-2.5 px-4 bg-rose-950/40 hover:bg-rose-900/50 border border-rose-500/10 text-rose-200 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
          >
            <Power className="w-4 h-4 text-rose-400" />
            Logout
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex border-b border-slate-800 gap-1 overflow-x-auto no-scrollbar">
        {[
          { id: 'queue', label: 'Incoming Queue 📥' },
          { id: 'pricing', label: 'Pricing List 🏷️' },
          { id: 'banner', label: 'Shop QR Poster 🖼' },
          { id: 'agent', label: 'PC Printer Agent ⚙️' }
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`py-3 px-5 text-xs font-black transition-all border-b-2 shrink-0 cursor-pointer ${
              activeTab === tab.id 
                ? 'border-indigo-500 text-indigo-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* ACTIVE TAB VIEWS */}
      {activeTab === 'queue' && (
        <div className="space-y-4">
          
          {/* Queue Header & Filters */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <h3 className="font-bold text-sm uppercase text-slate-400 tracking-wider">Live Customer Orders</h3>
            <div className="flex gap-1 overflow-x-auto no-scrollbar w-full sm:w-auto">
              {[
                { filter: 'all', label: 'All Jobs' },
                { filter: 'PENDING', label: '🔴 Pending' },
                { filter: 'PROCESSING', label: '🟡 Preparing' },
                { filter: 'PRINTED', label: '🟢 Printed' }
              ].map((btn) => (
                <button
                  key={btn.filter}
                  type="button"
                  onClick={() => setQueueFilter(btn.filter as any)}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-bold border transition shrink-0 cursor-pointer ${
                    queueFilter === btn.filter 
                      ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-600/20' 
                      : 'bg-white/5 border-white/10 text-slate-300 hover:text-white'
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </div>

          {/* Jobs List */}
          {filteredJobs.length === 0 ? (
            <div className="border border-dashed border-white/10 p-12 rounded-3xl text-center text-slate-400 bg-white/5 backdrop-blur-xl space-y-2">
              <Clock className="w-8 h-8 mx-auto text-slate-500 mb-2 animate-pulse" />
              <p className="text-xs font-bold text-slate-300">No active print jobs match this filter.</p>
              <p className="text-[10px] text-slate-400">The counter is currently empty! Show your shop QR code poster to customers.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredJobs.map((job) => (
                <div key={job.id} className="bg-white/5 border border-white/10 backdrop-blur-xl p-5 rounded-2xl space-y-4 relative overflow-hidden animate-fade-in shadow-lg">
                  <div className="absolute top-0 right-0 w-16 h-16 bg-indigo-500/5 rounded-full blur-xl pointer-events-none" />
                  
                  {/* Job Meta bar */}
                  <div className="flex justify-between items-start border-b border-white/10 pb-3">
                    <div>
                      <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded-md font-mono font-bold tracking-tight">#{job.id}</span>
                      <h4 className="font-black text-slate-100 text-xs mt-1.5">{job.customer_name}</h4>
                      {job.customer_mobile && (
                        <span className="text-[10px] text-slate-300 block font-mono mt-0.5">📞 {job.customer_mobile}</span>
                      )}
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 font-semibold block">{new Date(job.created_at).toLocaleTimeString()}</span>
                      <span className="text-indigo-400 font-bold font-mono text-xs block mt-1">₹{job.total_amount}</span>
                    </div>
                  </div>

                  {/* File Items and passcodes */}
                  <div className="space-y-2">
                    <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Uploaded Documents:</span>
                    {job.uploads && job.uploads.map((upl, idx) => (
                      <div key={upl.id || idx} className="p-2.5 bg-black/20 border border-white/5 rounded-xl flex items-center justify-between gap-3 text-xs animate-fade-in">
                        <div className="overflow-hidden truncate text-left">
                          <span className="font-bold text-slate-300 block truncate">{upl.file_name}</span>
                          <span className="text-[9px] text-slate-400 block uppercase font-mono">{upl.file_type || 'image/jpeg'} • {Math.round(upl.file_size / 1024)} KB</span>
                          
                          {upl.password && (
                            <span className="inline-block bg-red-500/10 border border-red-500/20 text-red-300 px-1.5 py-0.5 rounded text-[8px] font-bold mt-1 uppercase tracking-wide">
                              🔑 Passcode: {upl.password}
                            </span>
                          )}
                        </div>

                        <div className="shrink-0 flex items-center gap-1.5">
                          <a 
                            href={upl.file_url} 
                            target="_blank" 
                            rel="noreferrer"
                            className="p-1.5 hover:bg-white/10 text-indigo-400 rounded-lg transition"
                            title="Download Document"
                          >
                            <Download className="w-4 h-4" />
                          </a>
                          {(job.service_type === 'id_card' || job.service_type === 'passport') && (
                            <button
                              type="button"
                              onClick={() => setActiveStudioJob(job)}
                              className="p-1.5 hover:bg-white/10 text-indigo-400 rounded-lg transition cursor-pointer"
                              title="Open Custom Aligner Workbench"
                            >
                              <Sliders className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Job Controller Buttons */}
                  <div className="flex items-center justify-between gap-4 pt-2 border-t border-white/10 text-xs">
                    {/* Status controllers */}
                    <div className="flex gap-1">
                      <button
                        type="button"
                        onClick={() => updateJobStatus(job.id, 'PROCESSING')}
                        className={`py-1 px-2.5 rounded-lg text-[9px] font-extrabold border transition cursor-pointer ${
                          job.status === 'PROCESSING' 
                            ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300' 
                            : 'bg-white/5 border-white/10 text-slate-400 hover:text-slate-300'
                        }`}
                      >
                        Preparing
                      </button>
                      <button
                        type="button"
                        onClick={() => updateJobStatus(job.id, 'PRINTED')}
                        className={`py-1 px-2.5 rounded-lg text-[9px] font-extrabold border transition cursor-pointer ${
                          job.status === 'PRINTED' 
                            ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300' 
                            : 'bg-white/5 border-white/10 text-slate-400 hover:text-slate-300'
                        }`}
                      >
                        Mark Printed
                      </button>
                    </div>

                    {/* Payment controller */}
                    <div>
                      <button
                        type="button"
                        onClick={() => updateJobPayment(job.id, job.payment_status === 'PAID' ? 'PENDING' : 'PAID')}
                        className={`py-1 px-2.5 rounded-lg text-[9px] font-extrabold border transition flex items-center gap-1 cursor-pointer ${
                          job.payment_status === 'PAID'
                            ? 'bg-indigo-600/10 text-indigo-400 border-indigo-500/20'
                            : 'bg-rose-600/10 text-rose-400 border-rose-500/20'
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${job.payment_status === 'PAID' ? 'bg-indigo-400' : 'bg-rose-400'}`} />
                        {job.payment_status === 'PAID' ? 'Paid Direct' : 'Pending Payment'}
                      </button>
                    </div>
                  </div>

                </div>
              ))}
            </div>
          )}

        </div>
      )}

      {activeTab === 'pricing' && (
        <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl space-y-4 animate-fade-in shadow-lg">
          <div className="border-b border-white/10 pb-3">
            <h3 className="font-extrabold text-slate-100 text-sm">Xerox Services Pricing (मूल्य सूचि)</h3>
            <p className="text-[10px] text-slate-300 mt-1">Configure live prices customers see when they scan and submit documents</p>
          </div>

          <form onSubmit={updateServicesPricing} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {services.map((svc) => (
                <div key={svc.id} className="p-4 bg-black/20 border border-white/10 rounded-2xl flex items-center justify-between gap-4">
                  <div>
                    <span className="font-bold text-xs text-slate-200 block">{svc.service_label}</span>
                    <span className="text-[9px] font-mono text-slate-400 uppercase block mt-0.5">{svc.service_name}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">₹</span>
                      <input 
                        type="number"
                        min="1"
                        value={svc.price}
                        onChange={(e) => handlePriceChange(svc.id, 'price', parseInt(e.target.value) || 0)}
                        className="w-20 bg-black/30 border border-white/10 rounded-xl py-1.5 pl-6 pr-2 text-xs font-mono text-slate-100 text-right focus:outline-none"
                      />
                    </div>
                    <input 
                      type="checkbox"
                      checked={svc.enabled}
                      onChange={(e) => handlePriceChange(svc.id, 'enabled', e.target.checked)}
                      className="w-4.5 h-4.5 accent-indigo-500 rounded cursor-pointer"
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-white/10 text-right">
              <button
                type="submit"
                className="py-2.5 px-6 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold rounded-xl transition shadow cursor-pointer shadow-lg shadow-indigo-600/20"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}

      {activeTab === 'banner' && (
        <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-8 rounded-3xl text-center space-y-6 max-w-lg mx-auto animate-fade-in shadow-lg">
          <div className="space-y-2">
            <h3 className="font-extrabold text-slate-100 text-base">Your Counter QR Poster</h3>
            <p className="text-xs text-slate-300">Print or display this poster on your Xerox shop desk so customers can scan, upload docs, and send prints instantly.</p>
          </div>

          {/* Dynamic canvas QR area */}
          <div id="shop-printable-banner-canvas" className="p-6 bg-white rounded-3xl inline-block shadow-lg shadow-indigo-950/40 text-slate-950 mx-auto">
            <div className="text-center pb-3 text-slate-900">
              <h2 className="font-black text-lg tracking-tight uppercase">👉 Scan and Print Here</h2>
              <p className="text-[9px] text-slate-500 font-bold tracking-widest uppercase">Self-Service Document Portal</p>
            </div>
            {bannerQrCodeUrl ? (
              <img src={bannerQrCodeUrl} alt="Store Desk QR Poster" className="mx-auto block w-[260px] h-[260px]" />
            ) : (
              <div className="w-[260px] h-[260px] flex items-center justify-center bg-slate-100 text-slate-900 text-xs font-bold font-mono">Generating QR...</div>
            )}
            <div className="text-center pt-3 text-slate-900 font-mono text-[11px] font-bold">
              {currentUser.shop_name} ({currentUser.mobile})
            </div>
          </div>

          {/* Quick printing helper button */}
          <div className="flex gap-2 justify-center">
            <button
              type="button"
              onClick={() => {
                const style = document.createElement('style');
                style.id = 'dynamic-direct-print-layout';
                style.innerHTML = `
                  @media print {
                    body * {
                      visibility: hidden !important;
                      height: 0 !important;
                    }
                    #shop-printable-banner-canvas, #shop-printable-banner-canvas * {
                      visibility: visible !important;
                      height: auto !important;
                    }
                    #shop-printable-banner-canvas {
                      position: absolute !important;
                      left: 50% !important;
                      top: 50% !important;
                      transform: translate(-50%, -50%) scale(1.3) !important;
                    }
                  }
                `;
                document.head.appendChild(style);
                window.print();
                setTimeout(() => {
                  const el = document.getElementById('dynamic-direct-print-layout');
                  if (el) el.remove();
                }, 1000);
              }}
              className="py-2.5 px-5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition shadow flex items-center gap-2 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Print Desk Poster
            </button>
          </div>
        </div>
      )}

      {activeTab === 'agent' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 animate-fade-in">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="font-semibold text-slate-100 text-lg flex items-center gap-2">
                <Printer className="w-5 h-5 text-teal-400" />
                Windows/PC Auto-Print Agent Setup
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Install this node-agent background script to print automatically straight from customer uploads to your physical Xerox machine!
              </p>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={copyAgentCodeToClipboard}
                className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-xl transition cursor-pointer"
              >
                {copiedAgent ? (
                  <React.Fragment>
                    <Check className="w-4 h-4 text-teal-400" />
                    Copied!
                  </React.Fragment>
                ) : (
                  <React.Fragment>
                    <Sliders className="w-4 h-4 text-slate-400" />
                    Copy Script
                  </React.Fragment>
                )}
              </button>

              <button
                type="button"
                onClick={downloadAgentFile}
                className="flex items-center gap-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded-xl transition shadow cursor-pointer"
              >
                <Download className="w-4 h-4" />
                Download print-agent.js
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">How it works:</h4>
                <ol className="text-xs text-slate-400 space-y-3 list-decimal list-inside">
                  <li>
                    <strong className="text-slate-200">Download:</strong> Save the <code className="text-indigo-400 px-1 py-0.5 bg-slate-900 rounded">print-agent.js</code> file into a folder on your print desk Windows PC.
                  </li>
                  <li>
                    <strong className="text-slate-200">Install Node:</strong> Run terminal or command prompt inside that directory and execute:
                    <pre className="mt-2 bg-slate-900 p-2.5 rounded text-[10px] text-teal-400 overflow-x-auto border border-slate-850 leading-relaxed font-mono">
                      npm install node-fetch{"\n"}
                      node print-agent.js
                    </pre>
                  </li>
                  <li>
                    <strong className="text-slate-200">Continuous Print:</strong> The script connects to this live print queue and automatically fires print commands to your default connected printer spooler!
                  </li>
                </ol>
              </div>
            </div>

            <div className="lg:col-span-2 relative">
              <div className="absolute top-3 right-3 text-[10px] text-slate-500 font-mono select-none px-1.5 py-0.5 bg-slate-950 rounded border border-slate-800">
                Javascript Node.js (ESM)
              </div>
              <div className="text-[11px] text-slate-300 bg-slate-950 border border-slate-800 rounded-xl p-4 overflow-x-auto max-h-[280px] font-mono leading-relaxed">
                <pre>{agentCodeString}</pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PRINT STUDIO COMPANION WORKBENCH MODAL */}
      {activeStudioJob && (
        <PrintStudio 
          job={activeStudioJob} 
          onClose={() => setActiveStudioJob(null)}
          onJobUpdated={fetchJobsAndServices}
        />
      )}

    </div>
  );
}
