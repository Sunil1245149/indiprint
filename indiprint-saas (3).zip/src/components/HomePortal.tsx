import { Printer, Smartphone, Settings, Sparkles, ArrowLeftRight, Lock, Camera, ChevronRight } from 'lucide-react';

interface HomePortalProps {
  onNavigate: (page: 'home' | 'customer' | 'merchant') => void;
}

export default function HomePortal({ onNavigate }: HomePortalProps) {
  return (
    <div className="min-h-screen bg-transparent text-slate-100 flex flex-col justify-between selection:bg-indigo-500/30 selection:text-indigo-200">
      
      {/* Header */}
      <header className="bg-white/5 backdrop-blur-xl border-b border-white/10 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          
          {/* Brand Logo */}
          <button 
            type="button"
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 hover:opacity-90 transition text-left cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white font-extrabold shadow-lg shadow-indigo-500/25">
              <Printer className="w-5.5 h-5.5" />
            </div>
            <div>
              <span className="font-black text-lg tracking-tight bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">IndiPrint</span>
              <span className="text-[10px] text-indigo-400 block font-bold tracking-widest uppercase -mt-1 font-mono">Xerox SaaS</span>
            </div>
          </button>

          {/* Quick Links */}
          <div className="flex items-center gap-3">
            <button 
              onClick={() => onNavigate('customer')}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 text-slate-200 backdrop-blur-md transition cursor-pointer flex items-center gap-1.5"
            >
              <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
              Customer Desk
            </button>
            <button 
              onClick={() => onNavigate('merchant')}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition cursor-pointer flex items-center gap-1.5 shadow-lg shadow-indigo-600/20"
            >
              <Settings className="w-3.5 h-3.5 text-indigo-200" />
              Merchant Portal
            </button>
          </div>

        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-grow flex items-center">
        <div className="space-y-16 py-6 w-full">
          
          {/* Hero */}
          <div className="text-center max-w-3xl mx-auto space-y-6 relative py-12">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl -z-10"></div>
            
            <span className="bg-white/5 border border-white/10 text-slate-300 font-bold px-3 py-1.5 rounded-full text-xs inline-flex items-center gap-1.5 mx-auto backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
              Next-Gen Printing Automation for Indian Retail Stores
            </span>

            <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white leading-tight">
              Turn Your Xerox Counter Into a <span className="bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">Digital Print SaaS</span> Portal
            </h1>
            
            <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto leading-relaxed">
              Provide lightning-fast self-service uploading, cropping, background adjustments, and immediate UPI checkout directly from your customer's smartphones.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <button 
                onClick={() => onNavigate('merchant')}
                className="px-6 py-4 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-extrabold text-sm rounded-2xl tracking-wide transition shadow-lg shadow-indigo-650/20 flex items-center justify-center gap-2 cursor-pointer"
              >
                Merchant Setup Store (Dash)
                <ChevronRight className="w-4.5 h-4.5" />
              </button>

              <button 
                onClick={() => onNavigate('customer')}
                className="px-6 py-4 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 font-extrabold text-sm rounded-2xl tracking-wide backdrop-blur-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Smartphone className="w-4.5 h-4.5 text-indigo-400" />
                Enter Public Customer upload portal
              </button>
            </div>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl space-y-4 shadow-lg">
              <div className="w-10 h-10 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-400 border border-white/10">
                <ArrowLeftRight className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-slate-100 text-base">Automatic ID Booklets</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Avoid photocopying mistakes. Customers upload separate front and back snaps. IndiPrint stamps them side-by-side onto standard layout booklets instantly.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl space-y-4 shadow-lg">
              <div className="w-10 h-10 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-400 border border-white/10">
                <Lock className="w-5 h-5 text-indigo-400" />
              </div>
              <h3 className="font-extrabold text-slate-100 text-base">Secure PDF Passcodes</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Locked salary slips, bank statements, or utility documents? Customers provide decrypt passcodes alongside uploads so printers unlock files seamlessly.
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl space-y-4 shadow-lg">
              <div className="w-10 h-10 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-400 border border-white/10">
                <Camera className="w-5 h-5 text-indigo-400" />
              </div>
              <h3 className="font-extrabold text-slate-100 text-base">AI Passport Photo Grid</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Interactive portrait guide with instant background cropping, chroma key recolor (White, Royal Blue, Crimson Red), and 4-16 auto printing sheet grids.
              </p>
            </div>

          </div>

          {/* Agent Section */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 flex flex-col lg:flex-row items-center gap-8 justify-between relative overflow-hidden shadow-xl">
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-550/10 rounded-full blur-2xl"></div>
            
            <div className="space-y-4 max-w-xl">
              <span className="bg-white/10 text-indigo-300 border border-white/10 font-mono font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-full inline-block backdrop-blur-md">
                Automatic Printing Spooler Agent
              </span>
              <h2 className="text-2xl font-black text-slate-100 leading-7">No more WhatsApp spamming. Live Print directly to Canon / Epson.</h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                The SaaS features a downloadable Node.js Printer Agent command utility. Run this on your store Windows/PC. The agent automatically listens to online customer payments, downloads PDF files, and spits out print sheets automatically!
              </p>
            </div>

            <div className="bg-black/20 backdrop-blur-md p-4 border border-white/10 rounded-2xl shrink-0 space-y-2 w-full lg:w-auto">
              <span className="text-[10px] font-bold text-slate-400 block uppercase font-mono tracking-wider">Poll stream command example:</span>
              <pre className="text-xs text-indigo-400 font-mono font-bold select-all bg-black/30 p-2.5 rounded-lg border border-white/5">$ node print-agent.js --shop=royalXerox</pre>
              <span className="text-[9px] text-slate-400 block">✓ Connects to local printers spoolers instantly</span>
            </div>
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-transparent py-8 text-xs text-slate-400 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-2">
          <p className="font-mono text-[10px] text-slate-400 uppercase tracking-widest">IndiPrint SaaS System Workspace v1.4 • Made with AI Studio Developer Build</p>
          <div className="flex justify-center gap-4 text-slate-300">
            <span>Security Protocol Verified</span>
            <span>•</span>
            <span>UPI Sandbox Ready</span>
            <span>•</span>
            <span>NodeJS Agent Active</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
